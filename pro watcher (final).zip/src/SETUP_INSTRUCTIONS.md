# Two-Zone Business Website - Setup Instructions

## Overview

This application is a comprehensive two-zone website with:
- **ZONE A**: Public-facing website for lead capture
- **ZONE B**: Private staff portal for operations management

## Features

### Zone A - Public Website
1. **Home Page** - Hero section, services snapshot, how it works
2. **About Page** - Company story, values, team profiles
3. **Services Page** - Tiered packages with pricing
4. **Contact Page** - Inquiry form with backend storage
5. **Legal Pages** - Privacy Policy & Terms of Service
6. **Chat Widget** - Floating chat button for visitor support

### Zone B - Private Portal
7. **Login Page** - Secure authentication for staff
8. **Staff Dashboard** - Real-time chat management (Prowatcher)
9. **Chat History** - Searchable conversation logs
10. **Inquiry Management** - Lead tracking with status updates
11. **User Management** - Create/delete staff accounts (Admin only)
12. **Site Settings** - System configuration (Admin only)

## Initial Setup

### Step 1: Create Your First Admin User

Since this is a fresh installation, you'll need to create an admin user through the Supabase console:

1. Go to your Supabase project dashboard
2. Navigate to **Authentication** → **Users**
3. Click **Add User** → **Create new user**
4. Fill in:
   - Email: `admin@yourbrand.com` (or your preferred email)
   - Password: `YourSecurePassword123`
   - Auto Confirm User: **Yes** (check this box)
5. Click **Create User**
6. Click on the newly created user
7. Scroll to **User Metadata** section
8. Click **Edit** and add this JSON:
   ```json
   {
     "name": "Admin User",
     "role": "admin"
   }
   ```
9. Click **Save**

### Step 2: Login to the Portal

1. Visit your application
2. Click **Staff Login** in the navigation
3. Sign in with the admin credentials you just created
4. You should now see the Staff Dashboard

### Step 3: Create Additional Staff Users

From the admin account:
1. Navigate to **Users** in the portal navigation
2. Click **Add User**
3. Fill in the details and select a role:
   - **Agent**: Can view and respond to chats/inquiries
   - **Manager**: Agent permissions + can assign chats and update inquiry statuses
   - **Admin**: Full system access including user management and settings

## User Roles & Permissions

| Feature | Guest | Agent | Manager | Admin |
|---------|-------|-------|---------|-------|
| View public pages | ✅ | ✅ | ✅ | ✅ |
| Submit inquiries | ✅ | ✅ | ✅ | ✅ |
| Use chat widget | ✅ | ✅ | ✅ | ✅ |
| View chats/inquiries | ❌ | ✅ | ✅ | ✅ |
| Respond to chats | ❌ | ✅ | ✅ | ✅ |
| Assign chats | ❌ | ❌ | ✅ | ✅ |
| Update inquiry status | ❌ | ❌ | ✅ | ✅ |
| Manage users | ❌ | ❌ | ❌ | ✅ |
| Configure settings | ❌ | ❌ | ❌ | ✅ |

## How to Use

### For Public Visitors
- Navigate through the public pages to learn about services
- Submit an inquiry through the Contact page
- Use the chat widget (bottom right) to start a conversation
- All data is stored securely in Supabase

### For Staff Members
- Login through the **Staff Login** button
- **Dashboard**: Monitor and respond to active chats in real-time
- **Chat History**: Review past conversations
- **Inquiries**: Manage form submissions and update their status
- **Users** (Admin only): Create staff accounts
- **Settings** (Admin only): Configure chatbot behavior and system preferences

## Customization

### Branding
Edit these components to customize branding:
- `/components/Navigation.tsx` - Change "YourBrand" to your company name
- `/components/HomePage.tsx` - Update hero text, services, testimonials
- `/components/AboutPage.tsx` - Add your company story and team

### Images
- Current images are from Unsplash (royalty-free)
- Replace with your own images by updating the image URLs in each component

### Contact Information
Update contact details in:
- `/components/ContactPage.tsx`
- `/components/HomePage.tsx` (footer section)

### Services & Pricing
Edit service packages in:
- `/components/ServicesPage.tsx`

## Technical Architecture

### Backend (Supabase)
- **Authentication**: Built-in Supabase Auth with role-based access
- **Database**: KV Store for chats, inquiries, and settings
- **Real-time**: Chat polling every 3 seconds
- **Edge Functions**: `/supabase/functions/server/index.tsx`

### Frontend (React + Tailwind)
- **Routing**: Client-side routing via state management
- **Styling**: Tailwind CSS with shadcn/ui components
- **Forms**: React state management with validation

### API Endpoints
- `POST /inquiries` - Submit contact form
- `GET /inquiries` - Fetch all inquiries (protected)
- `PUT /inquiries/:id` - Update inquiry status (protected)
- `POST /chats` - Create new chat session
- `GET /chats` - Get all chats (protected)
- `POST /chats/:id/messages` - Send chat message
- `GET /users` - List users (admin only)
- `POST /auth/signup` - Create new user (admin only)
- `DELETE /users/:id` - Delete user (admin only)
- `GET /settings` - Get site settings (admin only)
- `PUT /settings` - Update settings (admin only)

## Important Notes

### Security
- Never share admin credentials
- Use strong passwords for all staff accounts
- The SUPABASE_SERVICE_ROLE_KEY is kept server-side only
- Row-level security is enforced through role checks

### Data Privacy
- This is a prototype/demo application
- Not recommended for storing sensitive PII in production
- For production use, implement proper data encryption and compliance measures

### Support
For technical issues:
1. Check browser console for errors
2. Review Supabase logs in the dashboard
3. Verify API endpoints are responding correctly

## Quick Start Checklist

- [ ] Create admin user in Supabase console
- [ ] Add role metadata to admin user
- [ ] Login to staff portal
- [ ] Create additional staff users
- [ ] Customize branding and content
- [ ] Update contact information
- [ ] Test chat widget functionality
- [ ] Test inquiry form submission
- [ ] Configure site settings (optional)

## Demo Workflow

1. **Visitor Journey**:
   - Visitor browses public website
   - Clicks chat widget or submits contact form
   - Receives auto-reply message

2. **Staff Response**:
   - Staff logs into dashboard
   - Sees active chat/inquiry notification
   - Assigns to self and responds
   - Updates status as conversation progresses
   - Closes chat when resolved

3. **Management**:
   - Manager reviews chat history
   - Updates inquiry statuses
   - Admin creates new staff accounts
   - Admin configures chatbot settings

---

**Ready to get started?** Create your admin user and explore the platform!
