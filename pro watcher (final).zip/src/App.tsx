import { useState, useEffect } from 'react';
import { createClient } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from './utils/supabase/info';
import { Toaster } from './components/ui/sonner';
import { createManagerAccount } from './utils/createManager';

// Zone A - Public Pages
import HomePage from './components/HomePage';
import AboutPage from './components/AboutPage';
import ServicesPage from './components/ServicesPage';
import ContactPage from './components/ContactPage';
import PrivacyPolicy from './components/PrivacyPolicy';
import TermsOfService from './components/TermsOfService';
import ProjectsPage from './components/ProjectsPage';

// Zone B - Private Portal
import LoginPage from './components/LoginPage';
import StaffDashboard from './components/StaffDashboard';
import ChatHistory from './components/ChatHistory';
import InquiryManagement from './components/InquiryManagement';
import UserManagement from './components/UserManagement';
import SiteSettings from './components/SiteSettings';
import DatabaseManagement from './components/DatabaseManagement';

// Components
import ChatWidget from './components/ChatWidget';
import Navigation from './components/Navigation';

const supabase = createClient(
  `https://${projectId}.supabase.co`,
  publicAnonKey
);

export default function App() {
  const [currentPage, setCurrentPage] = useState('home');
  const [user, setUser] = useState<any>(null);
  const [accessToken, setAccessToken] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    checkSession();
    // One-time setup: Create manager account if it doesn't exist
    const setupManager = async () => {
      const hasSetup = localStorage.getItem('manager-setup-complete');
      if (!hasSetup) {
        console.log('🔧 Running one-time manager account setup...');
        const result = await createManagerAccount();
        if (result.success) {
          localStorage.setItem('manager-setup-complete', 'true');
          if (result.alreadyExists) {
            console.log('ℹ️ Manager account already exists');
          } else {
            console.log('✅ Manager account setup complete!');
          }
          console.log('📧 Email: Manager@prowatcher.com.ph');
          console.log('🔑 Password: prowatchermanager');
        } else {
          console.error('❌ Failed to create manager account:', result.error);
        }
      } else {
        console.log('ℹ️ Manager account already configured');
        console.log('📧 Email: Manager@prowatcher.com.ph');
        console.log('🔑 Password: prowatchermanager');
      }
    };
    setupManager();
  }, []);

  const checkSession = async () => {
    try {
      const { data: { session }, error } = await supabase.auth.getSession();
      if (session?.user) {
        setUser(session.user);
        setAccessToken(session.access_token);
      }
    } catch (error) {
      console.error('Session check error:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleLogin = async (email: string, password: string) => {
    try {
      const { data: { session }, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      if (session) {
        setUser(session.user);
        setAccessToken(session.access_token);
        setCurrentPage('dashboard');
        return { success: true };
      }
    } catch (error: any) {
      console.error('Login error:', error);
      return { success: false, error: error.message };
    }
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      setUser(null);
      setAccessToken(null);
      setCurrentPage('home');
    } catch (error) {
      console.error('Logout error:', error);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">Loading...</div>
      </div>
    );
  }

  // Public routes (Zone A)
  const publicRoutes = ['home', 'about', 'services', 'contact', 'privacy', 'terms', 'projects'];
  const isPublicRoute = publicRoutes.includes(currentPage);

  // Protected routes (Zone B) - require authentication
  const protectedRoutes = ['dashboard', 'chat-history', 'inquiries', 'database', 'users', 'settings'];
  const isProtectedRoute = protectedRoutes.includes(currentPage);

  // Redirect to login if trying to access protected route without auth
  if (isProtectedRoute && !user) {
    return (
      <>
        <LoginPage onLogin={handleLogin} onNavigate={setCurrentPage} />
        <Toaster />
      </>
    );
  }

  // Render public pages with navigation and chat widget
  if (isPublicRoute) {
    return (
      <div className="min-h-screen bg-white">
        <Navigation 
          currentPage={currentPage} 
          onNavigate={setCurrentPage}
          isLoggedIn={!!user}
          onLogout={handleLogout}
        />

        <main>
          {currentPage === 'home' && <HomePage onNavigate={setCurrentPage} />}
          {currentPage === 'about' && <AboutPage />}
          {currentPage === 'services' && <ServicesPage onNavigate={setCurrentPage} />}
          {currentPage === 'contact' && <ContactPage />}
          {currentPage === 'privacy' && <PrivacyPolicy />}
          {currentPage === 'terms' && <TermsOfService />}
          {currentPage === 'projects' && <ProjectsPage />}
        </main>

        <ChatWidget />
        <Toaster />
      </div>
    );
  }

  // Render login page
  if (currentPage === 'login') {
    return (
      <>
        <LoginPage onLogin={handleLogin} onNavigate={setCurrentPage} />
        <Toaster />
      </>
    );
  }

  // Render protected portal pages (Zone B)
  return (
    <div className="min-h-screen bg-gray-50">
      {currentPage === 'dashboard' && (
        <StaffDashboard 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      {currentPage === 'chat-history' && (
        <ChatHistory 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      {currentPage === 'inquiries' && (
        <InquiryManagement 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      {currentPage === 'database' && (
        <DatabaseManagement 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      {currentPage === 'users' && (
        <UserManagement 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      {currentPage === 'settings' && (
        <SiteSettings 
          user={user}
          accessToken={accessToken}
          onNavigate={setCurrentPage}
          onLogout={handleLogout}
        />
      )}
      <Toaster />
    </div>
  );
}