/**
 * Utility script to create a manager account in Supabase
 * Run this once to create the manager account
 */

import { projectId, publicAnonKey } from './supabase/info';

export async function createManagerAccount() {
  try {
    const response = await fetch(
      `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/auth/signup`,
      {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${publicAnonKey}`,
        },
        body: JSON.stringify({
          email: 'Manager@prowatcher.com.ph',
          password: 'prowatchermanager',
          name: 'ProWatcher Manager',
          role: 'manager',
        }),
      }
    );

    const data = await response.json();

    if (response.ok) {
      return { success: true, data };
    } else if (response.status === 409) {
      // 409 Conflict means account already exists - this is fine
      return { success: true, data, alreadyExists: true };
    } else {
      return { success: false, error: data };
    }
  } catch (error) {
    console.error('❌ Error creating manager account:', error);
    return { success: false, error };
  }
}