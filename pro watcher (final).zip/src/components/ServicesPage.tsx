import { Check, ArrowRight, HelpCircle } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import {
  Accordion,
  AccordionContent,
  AccordionItem,
  AccordionTrigger,
} from './ui/accordion';
import { useState } from 'react';

interface ServicesPageProps {
  onNavigate: (page: string) => void;
}

export default function ServicesPage({ onNavigate }: ServicesPageProps) {
  const [expandedCards, setExpandedCards] = useState<number[]>([]);

  const toggleCard = (index: number) => {
    setExpandedCards(prev => 
      prev.includes(index) 
        ? prev.filter(i => i !== index)
        : [...prev, index]
    );
  };

  const packages = [
    {
      name: 'Building Management Systems (BMS)',
      price: 'Integrated Control',
      description: 'Honeywell-based centralized building automation',
      whoFor: 'Commercial buildings, offices, and facilities',
      features: [
        'Centralized HVAC control and monitoring',
        'Automated lighting management',
        'Energy monitoring and optimization',
        'Real-time system performance analytics',
        'Remote access and control capabilities',
        'Integration with existing building systems',
        'Custom dashboards and reporting',
        'Scheduled automation and set points',
      ],
      popular: false,
    },
    {
      name: 'Fire Detection & Alarm Systems (FDAS)',
      price: 'Life Safety',
      description: 'Code-compliant fire detection and alarm solutions',
      whoFor: 'All commercial, industrial, and healthcare facilities',
      features: [
        'System Sensor intelligent detection devices',
        'Morley control panels and interfaces',
        'Smoke, heat, and flame detectors',
        'Manual call points and sounders',
        'Emergency voice evacuation systems',
        'Code-compliant design and installation',
        'Integration with building management',
        'Regular testing and maintenance programs',
      ],
      popular: true,
    },
    {
      name: 'CCTV & Surveillance',
      price: 'Security Monitoring',
      description: 'Advanced video surveillance and analytics',
      whoFor: 'Security-conscious businesses and facilities',
      features: [
        'Honeywell IP and analog CCTV systems',
        'Hikvision AI-powered cameras',
        'High-definition video recording (up to 4K)',
        'Remote viewing via mobile and web',
        'Motion detection and analytics',
        'Night vision and low-light performance',
        'Video storage and archiving',
        'Integration with access control systems',
      ],
      popular: false,
    },
    {
      name: 'Access Control Systems',
      price: 'Secure Entry',
      description: 'Advanced access management and monitoring',
      whoFor: 'Offices, data centers, and restricted areas',
      features: [
        'Honeywell access control platforms',
        'Card readers and biometric systems',
        'Honeywell video intercom (IP-based)',
        'Multi-site access management',
        'Real-time access monitoring and reporting',
        'Time-based access permissions',
        'Integration with CCTV and alarm systems',
        'Visitor management capabilities',
      ],
      popular: false,
    },
    {
      name: 'Public Address Systems (PA)',
      price: 'Communication',
      description: 'Emergency and background audio solutions',
      whoFor: 'Schools, malls, offices, and public spaces',
      features: [
        'Emergency broadcasting and evacuation',
        'Background music distribution',
        'Zone-based audio control',
        'Integration with fire alarm systems',
        'IP-based and analog solutions',
        'Scheduled announcements and paging',
        'Clear audio coverage and quality',
        'Microphone and intercom stations',
      ],
      popular: false,
    },
    {
      name: 'Environmental Monitoring System (WATER LEAK DETECTION SYSTEM)',
      price: 'Facility Protection',
      description: 'Advanced water leak detection and environmental monitoring',
      whoFor: 'Data centers, server rooms, facilities with critical equipment',
      features: [
        'Real-time water leak detection sensors',
        'Automated alerts and notifications',
        'Zone-based monitoring and isolation',
        'Integration with building management systems',
        'Remote monitoring capabilities',
        'Preventive maintenance scheduling',
        'Temperature and humidity monitoring',
        'Comprehensive reporting and analytics',
      ],
      popular: false,
    },
  ];

  const processSteps = [
    {
      title: 'Discovery & Consultation',
      description: 'We start with a deep dive into your business, goals, and challenges. Our experts listen carefully to understand your unique needs.',
      timeline: '1-2 weeks',
    },
    {
      title: 'Strategy & Proposal',
      description: 'Based on our findings, we craft a detailed proposal with clear deliverables, timelines, and investment required.',
      timeline: '1 week',
    },
    {
      title: 'Agreement & Kickoff',
      description: 'Once you approve, we finalize the agreement and schedule a kickoff meeting with your dedicated team.',
      timeline: '3-5 days',
    },
    {
      title: 'Execution & Delivery',
      description: 'We get to work, keeping you informed every step of the way with regular updates and milestone check-ins.',
      timeline: 'Varies by project',
    },
    {
      title: 'Review & Optimization',
      description: 'After delivery, we review results together and make adjustments to ensure you\'re getting maximum value.',
      timeline: 'Ongoing',
    },
  ];

  const faqs = [
    {
      question: 'How long does a typical project take?',
      answer: 'Timeline varies based on project scope. Basic packages typically take 4-6 weeks, Standard packages 8-12 weeks, and Premium packages are customized based on your specific needs.',
    },
    {
      question: 'Can I upgrade my package later?',
      answer: 'Absolutely! Many clients start with a Basic package and upgrade as their needs grow. We make the transition seamless.',
    },
    {
      question: 'What if I\'m not satisfied?',
      answer: 'We offer a 30-day satisfaction guarantee. If you\'re not happy with our work in the first month, we\'ll refund your initial payment.',
    },
    {
      question: 'Do you work with businesses in my industry?',
      answer: 'We have experience across 20+ industries including tech, healthcare, finance, retail, and more. Schedule a consultation to discuss your specific industry needs.',
    },
    {
      question: 'What happens after the project is complete?',
      answer: 'We offer ongoing support and maintenance packages to ensure long-term success. You\'ll never be left without support.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-20 px-4" style={{ background: 'linear-gradient(to bottom right, var(--bg-color), white)' }}>
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl mb-6">Our Services</h1>
          <p className="text-xl text-gray-600">
            Flexible packages designed to meet you wherever you are in your business journey
          </p>
        </div>
      </section>

      {/* Service Packages */}
      <section className="py-20 px-4" aria-labelledby="services-heading">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 id="services-heading" className="text-4xl mb-4">Our Building Systems Solutions</h2>
            <p className="text-xl text-gray-600">
              Professional installation and integration services
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {packages.map((pkg, index) => {
              const isExpanded = expandedCards.includes(index);
              
              return (
                <Card
                  key={index}
                  style={{
                    border: pkg.popular ? '2px solid var(--p-color)' : '',
                  }}
                  className={`p-8 relative transition-all duration-300 hover:shadow-2xl focus-within:ring-2 focus-within:ring-offset-2 ${
                    pkg.popular ? 'shadow-xl' : ''
                  }`}
                  role="article"
                  aria-label={`${pkg.name} service package`}
                >
                  {pkg.popular && (
                    <div className="absolute -top-4 left-1/2 transform -translate-x-1/2">
                      <span 
                        className="text-white px-4 py-1 rounded-full text-sm shadow-md" 
                        style={{ backgroundColor: 'var(--p-color)' }}
                        role="status"
                        aria-label="Most popular service"
                      >
                        Most Popular
                      </span>
                    </div>
                  )}

                  <div className="text-center mb-6">
                    <h3 className="text-2xl mb-3">{pkg.name}</h3>
                    <div 
                      className="text-2xl mb-2 uppercase tracking-wide" 
                      style={{ color: 'var(--p-color)' }}
                      aria-label={`Service category: ${pkg.price}`}
                    >
                      {pkg.price}
                    </div>
                    <p className="text-gray-600">{pkg.description}</p>
                  </div>

                  <div 
                    className="mb-6 p-4 rounded-lg border-l-4 text-sm" 
                    style={{ 
                      backgroundColor: 'rgba(170, 5, 16, 0.05)',
                      borderLeftColor: 'var(--p-color)'
                    }}
                    role="note"
                    aria-label="Target audience"
                  >
                    <strong className="block mb-1" style={{ color: 'var(--p-color)' }}>Ideal for:</strong> 
                    <span className="text-gray-700">{pkg.whoFor}</span>
                  </div>

                  {/* Expandable Features Section */}
                  <div className="mb-6">
                    <button
                      onClick={() => toggleCard(index)}
                      className="w-full flex items-center justify-between p-3 rounded-lg border transition-all duration-200 hover:bg-gray-50"
                      style={{
                        borderColor: isExpanded ? 'var(--p-color)' : '#e5e7eb',
                        backgroundColor: isExpanded ? 'rgba(170, 5, 16, 0.05)' : 'white',
                      }}
                      aria-expanded={isExpanded}
                      aria-label={`${isExpanded ? 'Hide' : 'Show'} features for ${pkg.name}`}
                    >
                      <span style={{ color: isExpanded ? 'var(--p-color)' : '#1f2937' }}>
                        {isExpanded ? 'Hide Features' : 'View Features'}
                      </span>
                      <ArrowRight 
                        className={`w-5 h-5 transition-transform duration-200 ${isExpanded ? 'rotate-90' : ''}`}
                        style={{ color: isExpanded ? 'var(--p-color)' : '#6b7280' }}
                        aria-hidden="true"
                      />
                    </button>

                    <div 
                      className="overflow-hidden transition-all duration-300"
                      style={{
                        maxHeight: isExpanded ? '500px' : '0',
                        opacity: isExpanded ? 1 : 0,
                      }}
                    >
                      <div className="pt-4">
                        <h4 className="sr-only">Service features</h4>
                        <ul className="space-y-3" role="list">
                          {pkg.features.map((feature, i) => (
                            <li key={i} className="flex items-start gap-3 group">
                              <Check 
                                className="w-5 h-5 text-green-600 flex-shrink-0 mt-0.5 transition-transform group-hover:scale-110" 
                                aria-hidden="true"
                              />
                              <span className="text-sm text-gray-700 leading-relaxed">{feature}</span>
                            </li>
                          ))}
                        </ul>
                      </div>
                    </div>
                  </div>

                  <Button
                    className="w-full transition-all duration-200 hover:scale-105 active:scale-95 focus:ring-2 focus:ring-offset-2"
                    variant={pkg.popular ? 'default' : 'outline'}
                    onClick={() => onNavigate('contact')}
                    aria-label={`Get started with ${pkg.name}`}
                  >
                    Request Quote
                    <ArrowRight className="ml-2 w-4 h-4" aria-hidden="true" />
                  </Button>
                </Card>
              );
            })}
          </div>

          <div className="text-center mt-12 max-w-2xl mx-auto">
            <p className="text-gray-600 text-lg">
              <strong>Custom Solutions Available:</strong> All services can be tailored to your specific facility requirements. 
              <button 
                onClick={() => onNavigate('contact')}
                className="ml-1 underline hover:no-underline transition-all"
                style={{ color: 'var(--p-color)' }}
                aria-label="Contact us for custom solutions"
              >
                Contact us for a consultation
              </button>
            </p>
          </div>
        </div>
      </section>

      {/* FAQs */}
      <section className="py-20 px-4">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">Frequently Asked Questions</h2>
            <p className="text-xl text-gray-600">
              Common questions answered
            </p>
          </div>

          <Accordion type="single" collapsible className="space-y-4">
            {faqs.map((faq, index) => (
              <AccordionItem key={index} value={`item-${index}`} className="border rounded-lg px-6">
                <AccordionTrigger className="text-left">
                  <div className="flex items-center gap-3">
                    <HelpCircle className="w-5 h-5 flex-shrink-0" style={{ color: 'var(--p-color)' }} />
                    <span>{faq.question}</span>
                  </div>
                </AccordionTrigger>
                <AccordionContent className="text-gray-600 pl-8">
                  {faq.answer}
                </AccordionContent>
              </AccordionItem>
            ))}
          </Accordion>

          <div className="text-center mt-12">
            <p className="text-gray-600 mb-4">Still have questions?</p>
            <Button variant="outline" onClick={() => onNavigate('contact')}>
              Contact Us
            </Button>
          </div>
        </div>
      </section>
    </div>
  );
}