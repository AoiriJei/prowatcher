import { useState, useEffect } from 'react';
import { Search, Calendar, User, MessageCircle, ChevronDown, ChevronUp } from 'lucide-react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import { projectId } from '../utils/supabase/info';
import PortalNav from './PortalNav';

interface ChatHistoryProps {
  user: any;
  accessToken: string | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function ChatHistory({ user, accessToken, onNavigate, onLogout }: ChatHistoryProps) {
  const [chats, setChats] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [expandedChat, setExpandedChat] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchChats();
  }, []);

  const fetchChats = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        // Sort by most recent first
        const sorted = data.chats.sort((a: any, b: any) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setChats(sorted);
      }
    } catch (error) {
      console.error('Error fetching chats:', error);
    } finally {
      setLoading(false);
    }
  };

  const filteredChats = chats.filter((chat) => {
    const searchLower = searchTerm.toLowerCase();
    return (
      chat.guestName.toLowerCase().includes(searchLower) ||
      chat.guestEmail?.toLowerCase().includes(searchLower) ||
      chat.id.toLowerCase().includes(searchLower)
    );
  });

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalNav
        currentPage="chat-history"
        user={user}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Chat History</h1>
          <p className="text-gray-600">View and search past conversations</p>
        </div>

        {/* Search */}
        <Card className="p-4 mb-6">
          <div className="flex items-center gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by guest name, email, or chat ID..."
                className="pl-10"
              />
            </div>
          </div>
        </Card>

        {/* Chat List */}
        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading chat history...</div>
        ) : filteredChats.length === 0 ? (
          <Card className="p-12 text-center">
            <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-600">
              {searchTerm ? 'No chats match your search' : 'No chat history available'}
            </p>
          </Card>
        ) : (
          <div className="space-y-3">
            {filteredChats.map((chat) => (
              <Card key={chat.id} className="overflow-hidden">
                <button
                  onClick={() => setExpandedChat(expandedChat === chat.id ? null : chat.id)}
                  className="w-full p-4 text-left hover:bg-gray-50 transition-colors"
                >
                  <div className="flex items-start justify-between">
                    <div className="flex-1">
                      <div className="flex items-center gap-3 mb-2">
                        <div className="flex items-center gap-2">
                          <User className="w-4 h-4 text-gray-400" />
                          <span className="font-medium">{chat.guestName}</span>
                        </div>
                        <Badge variant={chat.status === 'active' ? 'default' : 'secondary'}>
                          {chat.status}
                        </Badge>
                        {chat.messages.length > 0 && (
                          <Badge variant="outline">
                            {chat.messages.length} messages
                          </Badge>
                        )}
                      </div>
                      
                      {chat.guestEmail && (
                        <p className="text-sm text-gray-500 mb-2">{chat.guestEmail}</p>
                      )}
                      
                      <div className="flex items-center gap-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(chat.createdAt).toLocaleString()}
                        </div>
                        {chat.assignedTo && (
                          <div>Handled by: {chat.assignedTo.name}</div>
                        )}
                      </div>
                    </div>
                    
                    <div>
                      {expandedChat === chat.id ? (
                        <ChevronUp className="w-5 h-5 text-gray-400" />
                      ) : (
                        <ChevronDown className="w-5 h-5 text-gray-400" />
                      )}
                    </div>
                  </div>
                </button>

                {/* Expanded Messages */}
                {expandedChat === chat.id && (
                  <div className="border-t bg-gray-50 p-4">
                    <h4 className="text-sm mb-3">Conversation:</h4>
                    <div className="space-y-3 max-h-96 overflow-y-auto">
                      {chat.messages.map((msg: any) => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[80%] rounded-lg px-3 py-2 ${
                              msg.sender === 'agent'
                                ? 'bg-blue-600 text-white'
                                : 'bg-white border'
                            }`}
                          >
                            <div className={`text-xs mb-1 ${msg.sender === 'agent' ? 'text-blue-100' : 'text-gray-500'}`}>
                              {msg.senderName}
                            </div>
                            <p className="text-sm">{msg.text}</p>
                            <div className={`text-xs mt-1 ${msg.sender === 'agent' ? 'text-blue-100' : 'text-gray-400'}`}>
                              {new Date(msg.timestamp).toLocaleTimeString([], { 
                                hour: '2-digit', 
                                minute: '2-digit' 
                              })}
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </Card>
            ))}
          </div>
        )}

        <div className="mt-6 text-center text-sm text-gray-500">
          Showing {filteredChats.length} of {chats.length} total chats
        </div>
      </div>
    </div>
  );
}
