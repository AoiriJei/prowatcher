import { useState, useEffect } from 'react';
import { Search, Mail, Calendar, Building, Filter } from 'lucide-react';
import { Card } from './ui/card';
import { Input } from './ui/input';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { Button } from './ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from './ui/select';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';
import { toast } from 'sonner@2.0.3';
import { projectId } from '../utils/supabase/info';
import PortalNav from './PortalNav';

interface InquiryManagementProps {
  user: any;
  accessToken: string | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function InquiryManagement({ user, accessToken, onNavigate, onLogout }: InquiryManagementProps) {
  const [inquiries, setInquiries] = useState<any[]>([]);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [selectedInquiry, setSelectedInquiry] = useState<any | null>(null);
  const [newNote, setNewNote] = useState('');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetchInquiries();
  }, []);

  const fetchInquiries = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/inquiries`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const sorted = data.inquiries.sort((a: any, b: any) => 
          new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()
        );
        setInquiries(sorted);
      }
    } catch (error) {
      console.error('Error fetching inquiries:', error);
    } finally {
      setLoading(false);
    }
  };

  const updateStatus = async (inquiryId: string, status: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/inquiries/${inquiryId}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ status }),
        }
      );

      if (response.ok) {
        toast.success('Status updated');
        fetchInquiries();
        if (selectedInquiry?.id === inquiryId) {
          const updatedInquiry = { ...selectedInquiry, status };
          setSelectedInquiry(updatedInquiry);
        }
      }
    } catch (error) {
      console.error('Error updating status:', error);
      toast.error('Failed to update status');
    }
  };

  const addNote = async () => {
    if (!newNote.trim() || !selectedInquiry) return;

    const note = {
      text: newNote,
      author: user.user_metadata?.name || user.email,
      timestamp: new Date().toISOString(),
    };

    try {
      const updatedNotes = [...(selectedInquiry.notes || []), note];
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/inquiries/${selectedInquiry.id}`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ notes: updatedNotes }),
        }
      );

      if (response.ok) {
        toast.success('Note added');
        setNewNote('');
        fetchInquiries();
        const updatedInquiry = { ...selectedInquiry, notes: updatedNotes };
        setSelectedInquiry(updatedInquiry);
      }
    } catch (error) {
      console.error('Error adding note:', error);
      toast.error('Failed to add note');
    }
  };

  const filteredInquiries = inquiries.filter((inquiry) => {
    const matchesSearch = 
      inquiry.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inquiry.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      inquiry.company?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || inquiry.status === statusFilter;
    
    return matchesSearch && matchesStatus;
  });

  const getStatusColor = (status: string) => {
    const colors: Record<string, string> = {
      new: 'bg-blue-500',
      contacted: 'bg-yellow-500',
      quoted: 'bg-purple-500',
      closed: 'bg-green-500',
    };
    return colors[status] || 'bg-gray-500';
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalNav
        currentPage="inquiries"
        user={user}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Inquiry Management</h1>
          <p className="text-gray-600">Track and manage form submissions</p>
        </div>

        {/* Filters */}
        <Card className="p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                placeholder="Search by name, email, or company..."
                className="pl-10"
              />
            </div>
            <div className="sm:w-48">
              <Select value={statusFilter} onValueChange={setStatusFilter}>
                <SelectTrigger>
                  <div className="flex items-center gap-2">
                    <Filter className="w-4 h-4" />
                    <SelectValue />
                  </div>
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Status</SelectItem>
                  <SelectItem value="new">New</SelectItem>
                  <SelectItem value="contacted">Contacted</SelectItem>
                  <SelectItem value="quoted">Quoted</SelectItem>
                  <SelectItem value="closed">Closed</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </Card>

        {/* Inquiries Table */}
        {loading ? (
          <div className="text-center py-12 text-gray-500">Loading inquiries...</div>
        ) : filteredInquiries.length === 0 ? (
          <Card className="p-12 text-center">
            <Mail className="w-16 h-16 mx-auto mb-4 text-gray-300" />
            <p className="text-gray-600">
              {searchTerm || statusFilter !== 'all' ? 'No inquiries match your filters' : 'No inquiries yet'}
            </p>
          </Card>
        ) : (
          <Card className="overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full">
                <thead className="bg-gray-50 border-b">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Status</th>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Name</th>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Email</th>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Service</th>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Date</th>
                    <th className="px-6 py-3 text-left text-xs uppercase text-gray-500">Actions</th>
                  </tr>
                </thead>
                <tbody className="divide-y">
                  {filteredInquiries.map((inquiry) => (
                    <tr key={inquiry.id} className="hover:bg-gray-50">
                      <td className="px-6 py-4">
                        <Badge className={getStatusColor(inquiry.status)}>
                          {inquiry.status}
                        </Badge>
                      </td>
                      <td className="px-6 py-4">
                        <div className="font-medium">{inquiry.name}</div>
                        {inquiry.company && (
                          <div className="text-sm text-gray-500 flex items-center gap-1 mt-1">
                            <Building className="w-3 h-3" />
                            {inquiry.company}
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-600">{inquiry.email}</td>
                      <td className="px-6 py-4">
                        <Badge variant="outline">{inquiry.service}</Badge>
                      </td>
                      <td className="px-6 py-4 text-sm text-gray-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-4 h-4" />
                          {new Date(inquiry.createdAt).toLocaleDateString()}
                        </div>
                      </td>
                      <td className="px-6 py-4">
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => setSelectedInquiry(inquiry)}
                        >
                          View Details
                        </Button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </Card>
        )}

        <div className="mt-6 text-center text-sm text-gray-500">
          Showing {filteredInquiries.length} of {inquiries.length} total inquiries
        </div>
      </div>

      {/* Detail Dialog */}
      <Dialog open={!!selectedInquiry} onOpenChange={() => setSelectedInquiry(null)}>
        <DialogContent className="max-w-2xl max-h-[80vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle>Inquiry Details</DialogTitle>
          </DialogHeader>

          {selectedInquiry && (
            <div className="space-y-6">
              {/* Contact Info */}
              <div>
                <h3 className="mb-3">Contact Information</h3>
                <div className="grid grid-cols-2 gap-4 text-sm">
                  <div>
                    <span className="text-gray-500">Name:</span>
                    <p className="font-medium">{selectedInquiry.name}</p>
                  </div>
                  <div>
                    <span className="text-gray-500">Email:</span>
                    <p className="font-medium">{selectedInquiry.email}</p>
                  </div>
                  {selectedInquiry.company && (
                    <div>
                      <span className="text-gray-500">Company:</span>
                      <p className="font-medium">{selectedInquiry.company}</p>
                    </div>
                  )}
                  <div>
                    <span className="text-gray-500">Service:</span>
                    <p className="font-medium capitalize">{selectedInquiry.service}</p>
                  </div>
                </div>
              </div>

              {/* Message */}
              <div>
                <h3 className="mb-2">Message</h3>
                <p className="text-sm text-gray-700 bg-gray-50 p-4 rounded">
                  {selectedInquiry.message}
                </p>
              </div>

              {/* Status Update */}
              <div>
                <h3 className="mb-2">Update Status</h3>
                <Select
                  value={selectedInquiry.status}
                  onValueChange={(value) => updateStatus(selectedInquiry.id, value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="new">New</SelectItem>
                    <SelectItem value="contacted">Contacted</SelectItem>
                    <SelectItem value="quoted">Quoted</SelectItem>
                    <SelectItem value="closed">Closed</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              {/* Notes */}
              <div>
                <h3 className="mb-2">Internal Notes</h3>
                <div className="space-y-2 mb-4">
                  {selectedInquiry.notes?.map((note: any, index: number) => (
                    <div key={index} className="bg-gray-50 p-3 rounded text-sm">
                      <div className="flex justify-between items-start mb-1">
                        <span className="font-medium">{note.author}</span>
                        <span className="text-xs text-gray-500">
                          {new Date(note.timestamp).toLocaleString()}
                        </span>
                      </div>
                      <p className="text-gray-700">{note.text}</p>
                    </div>
                  ))}
                  {(!selectedInquiry.notes || selectedInquiry.notes.length === 0) && (
                    <p className="text-sm text-gray-500 text-center py-4">No notes yet</p>
                  )}
                </div>
                <div className="flex gap-2">
                  <Textarea
                    value={newNote}
                    onChange={(e) => setNewNote(e.target.value)}
                    placeholder="Add a note..."
                    rows={2}
                  />
                  <Button onClick={addNote}>Add Note</Button>
                </div>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
