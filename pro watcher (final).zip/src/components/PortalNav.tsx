import image_664a6dc66cb459802cd67264cdc457a498f7fa7a from 'figma:asset/664a6dc66cb459802cd67264cdc457a498f7fa7a.png';
import { MessageCircle, History, Inbox, Users, Settings, LogOut, Database, Home, Shield } from 'lucide-react';
import { Button } from './ui/button';
import logoImage from './imports/prowatcher-logo.png';

interface PortalNavProps {
  currentPage: string;
  user: any;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function PortalNav({ currentPage, user, onNavigate, onLogout }: PortalNavProps) {
  const isAdmin = user?.user_metadata?.role === 'admin';
  const isManager = user?.user_metadata?.role === 'manager';
  const userRole = user?.user_metadata?.role || 'agent';

  const navItems = [
    { id: 'dashboard', label: 'Live Chat', icon: <MessageCircle className="w-5 h-5" />, access: 'all' },
    { id: 'chat-history', label: 'Chat History', icon: <History className="w-5 h-5" />, access: 'all' },
    { id: 'inquiries', label: 'Inquiries', icon: <Inbox className="w-5 h-5" />, access: 'all' },
    { id: 'database', label: 'Database', icon: <Database className="w-5 h-5" />, access: 'admin' },
    { id: 'users', label: 'Users', icon: <Users className="w-5 h-5" />, access: 'admin' },
    { id: 'settings', label: 'Settings', icon: <Settings className="w-5 h-5" />, access: 'admin' },
  ];

  const filteredNavItems = navItems.filter(item => {
    if (item.access === 'all') return true;
    if (item.access === 'admin') return isAdmin || isManager;
    return false;
  });

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case 'admin': return 'bg-red-100 text-red-700 border-red-200';
      case 'manager': return 'bg-purple-100 text-purple-700 border-purple-200';
      case 'agent': return 'bg-blue-100 text-blue-700 border-blue-200';
      default: return 'bg-gray-100 text-gray-700 border-gray-200';
    }
  };

  return (
    <nav className="bg-white border-b shadow-sm" style={{ borderBottomColor: 'var(--border-color)' }}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6">
        {/* Top Bar */}
        <div className="flex justify-between items-center h-16">
          {/* Logo & Portal Name */}
          <div className="flex items-center gap-4">
            <button 
              onClick={() => onNavigate('home')} 
              className="flex items-center gap-3 hover:opacity-80 transition-opacity group"
              title="Back to Public Website"
            >
              <img 
                src={image_664a6dc66cb459802cd67264cdc457a498f7fa7a} 
                alt="ProWatcher Logo" 
                className="h-10 w-auto"
              />
              <div className="hidden sm:flex items-center gap-2">
                <Shield className="w-5 h-5" style={{ color: 'var(--p-color)' }} />
                <span className="text-lg" style={{ color: 'var(--s-color)' }}>Staff Portal</span>
              </div>
            </button>
          </div>

          {/* User Info & Actions */}
          <div className="flex items-center gap-3">
            <button
              onClick={() => onNavigate('home')}
              className="flex items-center gap-2 px-3 py-1.5 text-sm text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-lg transition-colors"
              title="Return to Public Website"
            >
              <Home className="w-4 h-4" />
              <span className="hidden md:inline">Public Site</span>
            </button>
            
            <div className="hidden sm:flex items-center gap-3 px-3 py-1.5 bg-gray-50 rounded-lg border">
              <div className="flex flex-col gap-1.5">
                <div className="text-sm font-medium leading-tight" style={{ color: 'var(--s-color)' }}>
                  {user?.user_metadata?.name || user?.email?.split('@')[0] || 'User'}
                </div>
                <div className={`text-xs font-medium px-2 py-0.5 rounded border capitalize w-fit leading-tight ${getRoleBadgeColor(userRole)}`}>
                  {userRole}
                </div>
              </div>
            </div>

            <Button 
              variant="ghost" 
              onClick={onLogout} 
              size="sm"
              className="hover:bg-red-50 hover:text-red-600"
              title="Sign Out"
            >
              <LogOut className="w-4 h-4 mr-2" />
              <span className="hidden md:inline">Logout</span>
            </Button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="flex gap-1 -mb-px overflow-x-auto">
          {filteredNavItems.map((item) => (
            <button
              key={item.id}
              onClick={() => onNavigate(item.id)}
              className={`flex items-center gap-2 px-4 py-3 border-b-2 transition-all whitespace-nowrap ${
                currentPage === item.id
                  ? 'border-current text-current'
                  : 'border-transparent text-gray-600 hover:text-gray-900 hover:bg-gray-50'
              }`}
              style={currentPage === item.id ? { 
                borderBottomColor: 'var(--p-color)',
                color: 'var(--p-color)'
              } : {}}
              title={item.label}
            >
              {item.icon}
              <span className="text-sm">{item.label}</span>
            </button>
          ))}
        </div>
      </div>
    </nav>
  );
}