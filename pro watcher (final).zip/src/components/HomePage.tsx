import { Shield, Camera, Bell, Settings, Lock, Phone, ArrowRight, Droplets } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import logoImage from 'figma:asset/664a6dc66cb459802cd67264cdc457a498f7fa7a.png';

interface HomePageProps {
  onNavigate: (page: string) => void;
}

export default function HomePage({ onNavigate }: HomePageProps) {
  const services = [
    {
      icon: <Settings className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Building Management Systems (BMS)',
      description: 'Honeywell-based centralized building automation with integrated HVAC control, lighting management, and energy monitoring.',
    },
    {
      icon: <Bell className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Fire Detection & Alarm Systems',
      description: 'Code-compliant fire detection and alarm solutions using System Sensor and Morley equipment for life safety.',
    },
    {
      icon: <Camera className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'CCTV & Surveillance',
      description: 'Advanced video surveillance with Honeywell and Hikvision AI-powered cameras, offering up to 4K high-definition recording.',
    },
    {
      icon: <Lock className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Access Control Systems',
      description: 'Honeywell access control platforms with card readers, biometric systems, and IP-based video intercom solutions.',
    },
    {
      icon: <Phone className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Public Address Systems',
      description: 'Emergency broadcasting and background music distribution with zone-based audio control and fire alarm integration.',
    },
    {
      icon: <Droplets className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Environmental Monitoring (Water Leak Detection)',
      description: 'Real-time water leak detection sensors with automated alerts, perfect for data centers and facilities with critical equipment.',
    },
  ];

  return (
    <div>
      {/* Hero Section */}
      <section className="py-20 px-4" style={{ background: 'linear-gradient(to bottom right, var(--bg-color), white)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl mb-6">
                Integrated Auxiliary Systems Solutions
              </h1>
              <p className="text-xl text-gray-600 mb-8">
                Supplying and installing reliable technologies that keep buildings secure, efficient, and connected.
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Button size="lg" onClick={() => onNavigate('contact')}>
                  Submit Inquiry
                  <ArrowRight className="ml-2 w-5 h-5" />
                </Button>
                <Button size="lg" variant="outline" onClick={() => onNavigate('services')}>
                  View Services
                </Button>
              </div>
              
              {/* Trust Signals */}
              <div className="mt-12">
                <div className="text-center">
                  <div className="text-3xl mb-2" style={{ color: 'var(--p-color)' }}>🏆 BEST Performing Contractor</div>
                  <div className="text-sm text-gray-600">Awarded by AFNI PHIL INC</div>
                </div>
              </div>
            </div>

            <div className="relative">
              <img
                src="https://images.unsplash.com/photo-1672073311074-f60c4a5e7b92?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzZWN1cml0eSUyMGNhbWVyYSUyMHN1cnZlaWxsYW5jZXxlbnwxfHx8fDE3NjY2NzA0MjN8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
                alt="Security systems and surveillance"
                className="rounded-lg shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">Our Core Expertise</h2>
            <p className="text-xl text-gray-600">
              End-to-end auxiliary system solutions for commercial and industrial facilities
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card key={index} className="p-6 hover:shadow-lg transition-shadow">
                <div className="mb-4">{service.icon}</div>
                <h3 className="text-xl mb-3">{service.title}</h3>
                <p className="text-gray-600 mb-4">{service.description}</p>
                <button
                  onClick={() => onNavigate('services')}
                  style={{ color: 'var(--p-color)' }}
                  className="hover:opacity-80 flex items-center transition-opacity"
                >
                  Learn More <ArrowRight className="ml-1 w-4 h-4" />
                </button>
              </Card>
            ))}
          </div>

          <div className="text-center mt-12">
            <Button size="lg" variant="outline" onClick={() => onNavigate('services')}>
              View All Services
            </Button>
          </div>
        </div>
      </section>

      {/* About Section */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">About Us</h2>
          </div>

          <div className="max-w-4xl mx-auto text-center">
            <p className="text-xl text-gray-600 mb-8">
              We specialize in the supply, installation, and integration of auxiliary systems, delivering reliable solutions backed by technical expertise, quality equipment, and professional project execution.
            </p>
            <Button size="lg" onClick={() => onNavigate('about')}>
              Learn More About Us
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 text-white" style={{ backgroundColor: 'var(--s-color)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-4 gap-8 mb-8">
            <div className="bg-[rgba(80,80,80,0)]">
              <div className="flex items-center gap-2 mb-4">
                <img 
                  src={logoImage} 
                  alt="ProWatcher Logo" 
                  className="h-10 w-auto"
                />
                <div className="brand-logo-text text-white">
                  <span className="text-[rgb(255,255,255)]">PRO</span>
                  <span className="brand-logo-watcher" style={{ color: 'var(--p-color)' }}>WATCHER</span>
                </div>
              </div>
              <p className="text-sm text-gray-400">
                Integrated auxiliary systems solutions for modern buildings
              </p>
            </div>
            <div>
              <h4 className="mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button onClick={() => onNavigate('home')} className="text-gray-400 hover:text-white">
                    Home
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('about')} className="text-gray-400 hover:text-white">
                    About
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('services')} className="text-gray-400 hover:text-white">
                    Services
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('contact')} className="text-gray-400 hover:text-white">
                    Contact
                  </button>
                </li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Contact</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li>info@prowatcher.com.ph</li>
                <li>+63 917 275 2840</li>
              </ul>
            </div>
            <div>
              <h4 className="mb-4">Legal</h4>
              <ul className="space-y-2 text-sm">
                <li>
                  <button onClick={() => onNavigate('privacy')} className="text-gray-400 hover:text-white">
                    Privacy Policy
                  </button>
                </li>
                <li>
                  <button onClick={() => onNavigate('terms')} className="text-gray-400 hover:text-white">
                    Terms of Service
                  </button>
                </li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
            © 2024 ProWatcher. All rights reserved.
          </div>
        </div>
      </footer>
    </div>
  );
}