export default function PrivacyPolicy() {
  return (
    <div className="min-h-screen py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl mb-6">Privacy Policy</h1>
        <p className="text-gray-600 mb-8">Last updated: December 26, 2024</p>

        <div className="space-y-6 text-gray-700">
          <section>
            <h2 className="text-2xl mb-3">1. Information We Collect</h2>
            <p>
              We collect information you provide directly to us when you:
            </p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Fill out a contact form or inquiry</li>
              <li>Use our chat widget</li>
              <li>Subscribe to our newsletter</li>
              <li>Communicate with us via email or phone</li>
              <li>Request quotes for security system installations</li>
            </ul>
            <p className="mt-3">
              This may include your name, email address, company name, phone number, property location, and any messages you send to us regarding your security needs.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">2. How We Use Your Information</h2>
            <p>We use the information we collect to:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Respond to your inquiries and provide customer service</li>
              <li>Send you information about our security system services</li>
              <li>Prepare quotes and proposals for security solutions</li>
              <li>Schedule site visits and installations</li>
              <li>Improve our website and services</li>
              <li>Comply with legal obligations</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-3">3. Information Sharing</h2>
            <p>
              We do not sell, rent, or share your personal information with third parties except:
            </p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>With your consent</li>
              <li>To comply with legal requirements</li>
              <li>To protect our rights and safety</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-3">4. Data Security</h2>
            <p>
              ProWatcher implements appropriate technical and organizational measures to protect your personal information against unauthorized access, alteration, disclosure, or destruction. As a security systems provider, we take data protection seriously and apply industry-standard security practices.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">5. Your Rights</h2>
            <p>You have the right to:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Access your personal information</li>
              <li>Correct inaccurate information</li>
              <li>Request deletion of your information</li>
              <li>Opt out of marketing communications</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-3">6. Cookies</h2>
            <p>
              We use cookies and similar tracking technologies to improve your browsing experience. You can control cookie settings through your browser preferences.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">7. Contact Us</h2>
            <p>
              If you have questions about this Privacy Policy, please contact us at:
              <br />
              Email: info@prowatcher.com.ph
              <br />
              Phone: +63 917 275 2840
              <br />
              Address: 309 Dir. A. Bunye, Manila, Kalakhang Maynila, Philippines
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}