export default function TermsOfService() {
  return (
    <div className="min-h-screen py-20 px-4">
      <div className="max-w-4xl mx-auto">
        <h1 className="text-4xl mb-6">Terms of Service</h1>
        <p className="text-gray-600 mb-8">Last updated: December 26, 2024</p>

        <div className="space-y-6 text-gray-700">
          <section>
            <h2 className="text-2xl mb-3">1. Acceptance of Terms</h2>
            <p>
              By accessing and using this website, you accept and agree to be bound by the terms and provision of this agreement. If you do not agree to these terms, please do not use our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">2. Services</h2>
            <p>
              ProWatcher provides integrated auxiliary systems solutions including Building Management Systems (BMS), Fire Detection and Alarm Systems (FDAS), CCTV Surveillance Systems, Access Control Systems, and Public Address Systems as described on our website. All services are subject to availability and may be modified without prior notice.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">3. User Responsibilities</h2>
            <p>You agree to:</p>
            <ul className="list-disc pl-6 mt-2 space-y-1">
              <li>Provide accurate and complete information</li>
              <li>Maintain the confidentiality of any account credentials</li>
              <li>Use our services only for lawful purposes</li>
              <li>Not interfere with or disrupt our services</li>
              <li>Provide accurate site information for security system assessments</li>
            </ul>
          </section>

          <section>
            <h2 className="text-2xl mb-3">4. Payment Terms</h2>
            <p>
              Payment terms are specified in individual service agreements. All fees are non-refundable unless otherwise stated in writing. We reserve the right to modify pricing with 30 days notice. Installation deposits may be required for security system projects.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">5. Intellectual Property</h2>
            <p>
              All content on this website, including text, graphics, logos, and software, is the property of ProWatcher and is protected by copyright and other intellectual property laws.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">6. Limitation of Liability</h2>
            <p>
              To the fullest extent permitted by law, ProWatcher shall not be liable for any indirect, incidental, special, or consequential damages arising from the use of our services.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">7. Termination</h2>
            <p>
              We reserve the right to terminate or suspend access to our services immediately, without prior notice, for any reason, including breach of these Terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">8. Changes to Terms</h2>
            <p>
              We reserve the right to modify these terms at any time. Changes will be effective immediately upon posting to the website. Your continued use of our services constitutes acceptance of modified terms.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">9. Governing Law</h2>
            <p>
              These terms shall be governed by and construed in accordance with the laws of the Republic of the Philippines, without regard to its conflict of law provisions.
            </p>
          </section>

          <section>
            <h2 className="text-2xl mb-3">10. Contact Information</h2>
            <p>
              For questions about these Terms of Service, please contact us at:
              <br />
              Email: info@prowatcher.com.ph
              <br />
              Phone: +63 917 275 2840
              <br />
              Address: 309 Dir. A. Bunye, Manila, Kalakhang Maynila, Philippines
            </p>
          </section>
        </div>
      </div>
    </div>
  );
}