import { useState, useEffect } from 'react';
import { Database, Trash2, Plus, RefreshCw, Search, Eye, EyeOff } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { toast } from 'sonner@2.0.3';
import { projectId } from '../utils/supabase/info';
import PortalNav from './PortalNav';

interface DatabaseManagementProps {
  user: any;
  accessToken: string | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function DatabaseManagement({ user, accessToken, onNavigate, onLogout }: DatabaseManagementProps) {
  const [entries, setEntries] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [showNewEntry, setShowNewEntry] = useState(false);
  const [newKey, setNewKey] = useState('');
  const [newValue, setNewValue] = useState('');
  const [expandedKeys, setExpandedKeys] = useState<Set<string>>(new Set());

  useEffect(() => {
    fetchData();
  }, []);

  const fetchData = async () => {
    setLoading(true);
    try {
      // Fetch all data from different prefixes
      const prefixes = ['inquiry:', 'chat:', 'site:', 'user:'];
      const allEntries: any[] = [];

      for (const prefix of prefixes) {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/database/prefix/${prefix}`,
          {
            headers: {
              'Authorization': `Bearer ${accessToken}`,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          if (data.entries) {
            allEntries.push(...data.entries);
          }
        }
      }

      setEntries(allEntries);
    } catch (error) {
      console.error('Error fetching database entries:', error);
      toast.error('Failed to fetch database entries');
    } finally {
      setLoading(false);
    }
  };

  const handleAddEntry = async () => {
    if (!newKey || !newValue) {
      toast.error('Key and value are required');
      return;
    }

    try {
      let parsedValue;
      try {
        parsedValue = JSON.parse(newValue);
      } catch {
        parsedValue = newValue;
      }

      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/database`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({ key: newKey, value: parsedValue }),
        }
      );

      if (response.ok) {
        toast.success('Entry added successfully');
        setNewKey('');
        setNewValue('');
        setShowNewEntry(false);
        fetchData();
      } else {
        toast.error('Failed to add entry');
      }
    } catch (error) {
      console.error('Error adding entry:', error);
      toast.error('Failed to add entry');
    }
  };

  const handleDeleteEntry = async (key: string) => {
    if (!confirm(`Are you sure you want to delete "${key}"?`)) {
      return;
    }

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/database/${encodeURIComponent(key)}`,
        {
          method: 'DELETE',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        toast.success('Entry deleted successfully');
        fetchData();
      } else {
        toast.error('Failed to delete entry');
      }
    } catch (error) {
      console.error('Error deleting entry:', error);
      toast.error('Failed to delete entry');
    }
  };

  const toggleExpanded = (key: string) => {
    const newExpanded = new Set(expandedKeys);
    if (newExpanded.has(key)) {
      newExpanded.delete(key);
    } else {
      newExpanded.add(key);
    }
    setExpandedKeys(newExpanded);
  };

  const filteredEntries = entries.filter(entry => 
    entry.key.toLowerCase().includes(searchTerm.toLowerCase()) ||
    JSON.stringify(entry.value).toLowerCase().includes(searchTerm.toLowerCase())
  );

  const getEntryType = (key: string) => {
    if (key.startsWith('inquiry:')) return { type: 'Inquiry', color: 'bg-blue-100 text-blue-700' };
    if (key.startsWith('chat:')) return { type: 'Chat', color: 'bg-green-100 text-green-700' };
    if (key.startsWith('site:')) return { type: 'Settings', color: 'bg-purple-100 text-purple-700' };
    if (key.startsWith('user:')) return { type: 'User', color: 'bg-orange-100 text-orange-700' };
    return { type: 'Other', color: 'bg-gray-100 text-gray-700' };
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <PortalNav
          currentPage="database"
          user={user}
          onNavigate={onNavigate}
          onLogout={onLogout}
        />
        <div className="max-w-7xl mx-auto p-6 text-center py-12 text-gray-500">
          Loading database...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalNav
        currentPage="database"
        user={user}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="max-w-7xl mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Database Management</h1>
          <p className="text-gray-600">View and manage all data stored in the system</p>
        </div>

        {/* Actions Bar */}
        <Card className="p-4 mb-6">
          <div className="flex flex-col md:flex-row gap-4 items-end md:items-center justify-between">
            <div className="flex-1 max-w-md">
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 w-4 h-4 text-gray-400" />
                <Input
                  id="search"
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  placeholder="Search by key or value..."
                  className="pl-10"
                />
              </div>
            </div>

            <div className="flex gap-2">
              <Button onClick={fetchData} variant="outline">
                <RefreshCw className="w-4 h-4 mr-2" />
                Refresh
              </Button>
              <Button onClick={() => setShowNewEntry(!showNewEntry)}>
                <Plus className="w-4 h-4 mr-2" />
                Add Entry
              </Button>
            </div>
          </div>
        </Card>

        {/* New Entry Form */}
        {showNewEntry && (
          <Card className="p-6 mb-6">
            <h2 className="text-xl mb-4">Add New Entry</h2>
            <div className="space-y-4">
              <div>
                <Label htmlFor="new-key">Key</Label>
                <Input
                  id="new-key"
                  value={newKey}
                  onChange={(e) => setNewKey(e.target.value)}
                  placeholder="e.g., custom:mydata"
                />
              </div>
              <div>
                <Label htmlFor="new-value">Value (JSON or plain text)</Label>
                <Textarea
                  id="new-value"
                  value={newValue}
                  onChange={(e) => setNewValue(e.target.value)}
                  placeholder='{"key": "value"} or plain text'
                  rows={5}
                />
              </div>
              <div className="flex gap-2">
                <Button onClick={handleAddEntry}>Save Entry</Button>
                <Button variant="outline" onClick={() => setShowNewEntry(false)}>Cancel</Button>
              </div>
            </div>
          </Card>
        )}

        {/* Stats */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
          <Card className="p-4">
            <div className="text-sm text-gray-600">Total Entries</div>
            <div className="text-2xl mt-1">{entries.length}</div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-gray-600">Inquiries</div>
            <div className="text-2xl mt-1">{entries.filter(e => e.key.startsWith('inquiry:')).length}</div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-gray-600">Chats</div>
            <div className="text-2xl mt-1">{entries.filter(e => e.key.startsWith('chat:')).length}</div>
          </Card>
          <Card className="p-4">
            <div className="text-sm text-gray-600">Settings</div>
            <div className="text-2xl mt-1">{entries.filter(e => e.key.startsWith('site:')).length}</div>
          </Card>
        </div>

        {/* Entries List */}
        <Card className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
              <Database className="w-5 h-5 text-blue-600" />
            </div>
            <h2 className="text-xl">Database Entries ({filteredEntries.length})</h2>
          </div>

          {filteredEntries.length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              No entries found
            </div>
          ) : (
            <div className="space-y-3">
              {filteredEntries.map((entry, index) => {
                const { type, color } = getEntryType(entry.key);
                const isExpanded = expandedKeys.has(entry.key);

                return (
                  <div key={index} className="border rounded-lg p-4 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2">
                          <span className={`text-xs px-2 py-1 rounded ${color}`}>
                            {type}
                          </span>
                          <code className="text-sm font-mono text-gray-700 break-all">
                            {entry.key}
                          </code>
                        </div>
                        
                        <div className="text-sm">
                          <button
                            onClick={() => toggleExpanded(entry.key)}
                            className="flex items-center gap-2 text-gray-600 hover:text-gray-900 mb-2"
                          >
                            {isExpanded ? (
                              <EyeOff className="w-4 h-4" />
                            ) : (
                              <Eye className="w-4 h-4" />
                            )}
                            <span>{isExpanded ? 'Hide' : 'Show'} Value</span>
                          </button>

                          {isExpanded && (
                            <pre className="bg-gray-100 p-3 rounded text-xs overflow-x-auto">
                              {JSON.stringify(entry.value, null, 2)}
                            </pre>
                          )}
                        </div>
                      </div>

                      <Button
                        variant="ghost"
                        size="sm"
                        onClick={() => handleDeleteEntry(entry.key)}
                        className="flex-shrink-0"
                      >
                        <Trash2 className="w-4 h-4 text-red-500" />
                      </Button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </Card>

        {/* Info Banner */}
        <Card className="p-4 bg-blue-50 border-blue-200 mt-6">
          <div className="flex items-start gap-3">
            <Database className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
            <div className="text-sm">
              <p className="font-medium text-blue-900 mb-1">Database Information</p>
              <p className="text-blue-700">
                This interface allows you to view and manage all data stored in the key-value database. 
                Be careful when deleting entries as this action cannot be undone. System data like inquiries, 
                chats, and settings are automatically managed by the application.
              </p>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
