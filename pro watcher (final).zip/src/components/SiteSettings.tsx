import { useState, useEffect } from 'react';
import { Save, Settings as SettingsIcon, Clock, MessageSquare, Shield } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import { Textarea } from './ui/textarea';
import { Switch } from './ui/switch';
import { toast } from 'sonner@2.0.3';
import { projectId } from '../utils/supabase/info';
import PortalNav from './PortalNav';

interface SiteSettingsProps {
  user: any;
  accessToken: string | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function SiteSettings({ user, accessToken, onNavigate, onLogout }: SiteSettingsProps) {
  const [settings, setSettings] = useState({
    chatbotEnabled: true,
    operatingHours: '9 AM - 5 PM EST',
    autoReply: 'Thanks for reaching out! An agent will be with you shortly.',
    dataRetentionDays: 90,
  });
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    fetchSettings();
  }, []);

  const fetchSettings = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/settings`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        setSettings(data.settings);
      }
    } catch (error) {
      console.error('Error fetching settings:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSave = async () => {
    setSaving(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/settings`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify(settings),
        }
      );

      if (response.ok) {
        toast.success('Settings saved successfully');
      } else {
        toast.error('Failed to save settings');
      }
    } catch (error) {
      console.error('Error saving settings:', error);
      toast.error('Failed to save settings');
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <PortalNav
          currentPage="settings"
          user={user}
          onNavigate={onNavigate}
          onLogout={onLogout}
        />
        <div className="max-w-4xl mx-auto p-6 text-center py-12 text-gray-500">
          Loading settings...
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalNav
        currentPage="settings"
        user={user}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-6">
          <h1 className="text-3xl mb-2">Site Settings</h1>
          <p className="text-gray-600">Configure system behavior and preferences</p>
        </div>

        <div className="space-y-6">
          {/* Chatbot Settings */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
                <MessageSquare className="w-5 h-5 text-blue-600" />
              </div>
              <h2 className="text-xl">Chatbot Configuration</h2>
            </div>

            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <Label htmlFor="chatbot-enabled">Enable Chat Widget</Label>
                  <p className="text-sm text-gray-500">Show the chat button on public pages</p>
                </div>
                <Switch
                  id="chatbot-enabled"
                  checked={settings.chatbotEnabled}
                  onCheckedChange={(checked) => 
                    setSettings({ ...settings, chatbotEnabled: checked })
                  }
                />
              </div>

              <div>
                <Label htmlFor="auto-reply">Auto-Reply Message</Label>
                <Textarea
                  id="auto-reply"
                  value={settings.autoReply}
                  onChange={(e) => 
                    setSettings({ ...settings, autoReply: e.target.value })
                  }
                  placeholder="Message sent when a new chat starts"
                  rows={3}
                />
                <p className="text-xs text-gray-500 mt-1">
                  This message is automatically sent when a visitor starts a new chat.
                </p>
              </div>
            </div>
          </Card>

          {/* Operating Hours */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
                <Clock className="w-5 h-5 text-green-600" />
              </div>
              <h2 className="text-xl">Operating Hours</h2>
            </div>

            <div>
              <Label htmlFor="operating-hours">Business Hours</Label>
              <Input
                id="operating-hours"
                value={settings.operatingHours}
                onChange={(e) => 
                  setSettings({ ...settings, operatingHours: e.target.value })
                }
                placeholder="e.g., 9 AM - 5 PM EST"
              />
              <p className="text-xs text-gray-500 mt-1">
                Displayed to visitors in the chat widget and contact page.
              </p>
            </div>
          </Card>

          {/* Security Settings */}
          <Card className="p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
                <Shield className="w-5 h-5 text-purple-600" />
              </div>
              <h2 className="text-xl">Security & Data Retention</h2>
            </div>

            <div>
              <Label htmlFor="retention">Data Retention Period (days)</Label>
              <Input
                id="retention"
                type="number"
                value={settings.dataRetentionDays}
                onChange={(e) => 
                  setSettings({ ...settings, dataRetentionDays: parseInt(e.target.value) })
                }
                min={1}
                max={365}
              />
              <p className="text-xs text-gray-500 mt-1">
                How long to keep chat logs and inquiry data before automatic deletion.
              </p>
            </div>
          </Card>

          {/* Save Button */}
          <div className="flex gap-4">
            <Button onClick={handleSave} disabled={saving} size="lg">
              <Save className="w-4 h-4 mr-2" />
              {saving ? 'Saving...' : 'Save Settings'}
            </Button>
            <Button variant="outline" onClick={fetchSettings} size="lg">
              Reset Changes
            </Button>
          </div>

          {/* Info Banner */}
          <Card className="p-4 bg-blue-50 border-blue-200">
            <div className="flex items-start gap-3">
              <SettingsIcon className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-900 mb-1">Settings Information</p>
                <p className="text-blue-700">
                  Changes to these settings take effect immediately. Some settings like the auto-reply 
                  message will only apply to new conversations started after the change is saved.
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  );
}
