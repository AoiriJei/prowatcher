import { useState, useEffect, useRef } from 'react';
import { MessageCircle, Send, User, Clock, CheckCircle2, UserCheck, AlertCircle, Loader2 } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { Badge } from './ui/badge';
import { toast } from 'sonner@2.0.3';
import { projectId } from '../utils/supabase/info';
import PortalNav from './PortalNav';

interface StaffDashboardProps {
  user: any;
  accessToken: string | null;
  onNavigate: (page: string) => void;
  onLogout: () => void;
}

export default function StaffDashboard({ user, accessToken, onNavigate, onLogout }: StaffDashboardProps) {
  const [chats, setChats] = useState<any[]>([]);
  const [selectedChat, setSelectedChat] = useState<any | null>(null);
  const [message, setMessage] = useState('');
  const [loading, setLoading] = useState(true);
  const [sending, setSending] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    fetchChats();
    const interval = setInterval(fetchChats, 3000); // Poll every 3 seconds
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    // Auto-scroll to bottom when messages change
    scrollToBottom();
  }, [selectedChat?.messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const fetchChats = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats`,
        {
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        const data = await response.json();
        const activeChats = data.chats.filter((chat: any) => chat.status === 'active');
        setChats(activeChats);
        
        // Update selected chat if it exists
        if (selectedChat) {
          const updated = activeChats.find((c: any) => c.id === selectedChat.id);
          if (updated) {
            setSelectedChat(updated);
          } else {
            // Chat was closed or deleted
            setSelectedChat(null);
          }
        }
      }
    } catch (error) {
      console.error('Error fetching chats:', error);
    } finally {
      setLoading(false);
    }
  };

  const assignToMe = async (chatId: string) => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}/assign`,
        {
          method: 'PUT',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            agentId: user.id,
            agentName: user.user_metadata?.name || user.email?.split('@')[0] || 'Agent',
          }),
        }
      );

      if (response.ok) {
        toast.success('Chat assigned to you');
        fetchChats();
      } else {
        toast.error('Failed to assign chat');
      }
    } catch (error) {
      console.error('Error assigning chat:', error);
      toast.error('Failed to assign chat');
    }
  };

  const sendMessage = async () => {
    if (!message.trim() || !selectedChat || sending) return;

    const messageText = message;
    setMessage('');
    setSending(true);

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${selectedChat.id}/messages`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${accessToken}`,
          },
          body: JSON.stringify({
            message: messageText,
            sender: 'agent',
            senderName: user.user_metadata?.name || user.email?.split('@')[0] || 'Agent',
          }),
        }
      );

      if (response.ok) {
        fetchChats();
      } else {
        toast.error('Failed to send message');
        setMessage(messageText); // Restore message on error
      }
    } catch (error) {
      console.error('Error sending message:', error);
      toast.error('Failed to send message');
      setMessage(messageText); // Restore message on error
    } finally {
      setSending(false);
    }
  };

  const closeChat = async (chatId: string) => {
    if (!confirm('Are you sure you want to close this chat?')) return;

    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}/close`,
        {
          method: 'PUT',
          headers: {
            'Authorization': `Bearer ${accessToken}`,
          },
        }
      );

      if (response.ok) {
        toast.success('Chat closed successfully');
        setSelectedChat(null);
        fetchChats();
      } else {
        toast.error('Failed to close chat');
      }
    } catch (error) {
      console.error('Error closing chat:', error);
      toast.error('Failed to close chat');
    }
  };

  const formatTime = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / 60000);
    
    if (diffInMinutes < 1) return 'Just now';
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`;
    if (diffInMinutes < 1440) return date.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    return date.toLocaleDateString([], { month: 'short', day: 'numeric' });
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <PortalNav
        currentPage="dashboard"
        user={user}
        onNavigate={onNavigate}
        onLogout={onLogout}
      />

      <div className="max-w-7xl mx-auto p-4 sm:p-6">
        {/* Header */}
        <div className="mb-6">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-10 h-10 rounded-lg flex items-center justify-center" style={{ backgroundColor: 'var(--p-color)' }}>
              <MessageCircle className="w-5 h-5 text-white" />
            </div>
            <h1 className="text-3xl">Live Chat Dashboard</h1>
          </div>
          <p className="text-gray-600">Manage active conversations with visitors in real-time</p>
        </div>

        {/* Stats Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Active Chats</p>
                <p className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>{chats.length}</p>
              </div>
              <MessageCircle className="w-8 h-8 text-blue-200" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Unassigned</p>
                <p className="text-2xl mt-1 text-orange-600">{chats.filter(c => !c.assignedTo).length}</p>
              </div>
              <AlertCircle className="w-8 h-8 text-orange-200" />
            </div>
          </Card>
          <Card className="p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">My Chats</p>
                <p className="text-2xl mt-1 text-green-600">{chats.filter(c => c.assignedTo?.id === user.id).length}</p>
              </div>
              <UserCheck className="w-8 h-8 text-green-200" />
            </div>
          </Card>
        </div>

        <div className="grid lg:grid-cols-3 gap-6">
          {/* Active Chats List */}
          <Card className="lg:col-span-1 p-4 h-[calc(100vh-320px)] flex flex-col">
            <div className="flex items-center justify-between mb-4">
              <h2 className="text-xl">Active Chats</h2>
              <Badge variant="secondary">{chats.length}</Badge>
            </div>
            
            {loading ? (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <Loader2 className="w-8 h-8 mx-auto mb-2 animate-spin text-gray-400" />
                  <p className="text-sm">Loading chats...</p>
                </div>
              </div>
            ) : chats.length === 0 ? (
              <div className="flex-1 flex items-center justify-center text-gray-500">
                <div className="text-center">
                  <MessageCircle className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                  <p className="text-sm">No active chats</p>
                  <p className="text-xs text-gray-400 mt-1">New chats will appear here</p>
                </div>
              </div>
            ) : (
              <div className="flex-1 overflow-y-auto space-y-2">
                {chats.map((chat) => {
                  const isSelected = selectedChat?.id === chat.id;
                  const isAssignedToMe = chat.assignedTo?.id === user.id;
                  const hasUnreadMessages = chat.messages.length > 0;
                  
                  return (
                    <button
                      key={chat.id}
                      onClick={() => setSelectedChat(chat)}
                      className={`w-full text-left p-3 rounded-lg border transition-all ${''}
                        ${isSelected ? 'border-2 shadow-sm' : 'hover:shadow-sm'}
                      `}
                      style={isSelected ? { 
                        backgroundColor: 'rgba(170, 5, 16, 0.05)',
                        borderColor: 'var(--p-color)'
                      } : {}}
                    >
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2 flex-1 min-w-0">
                          <div className="w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--t-color)' }}>
                            <User className="w-4 h-4 text-gray-600" />
                          </div>
                          <div className="flex-1 min-w-0">
                            <p className="truncate" style={{ color: 'var(--s-color)' }}>{chat.guestName}</p>
                            {chat.guestEmail && (
                              <p className="text-xs text-gray-500 truncate">{chat.guestEmail}</p>
                            )}
                          </div>
                        </div>
                        {hasUnreadMessages && (
                          <Badge 
                            variant="secondary" 
                            className="text-xs flex-shrink-0"
                            style={{ backgroundColor: 'var(--p-color)', color: 'white' }}
                          >
                            {chat.messages.length}
                          </Badge>
                        )}
                      </div>
                      
                      <div className="flex items-center justify-between text-xs">
                        {chat.assignedTo ? (
                          <Badge 
                            variant={isAssignedToMe ? "default" : "outline"} 
                            className="text-xs"
                            style={isAssignedToMe ? { backgroundColor: 'var(--p-color)' } : {}}
                          >
                            <UserCheck className="w-3 h-3 mr-1" />
                            {isAssignedToMe ? 'You' : chat.assignedTo.name}
                          </Badge>
                        ) : (
                          <Badge variant="secondary" className="text-xs bg-orange-100 text-orange-700">
                            <AlertCircle className="w-3 h-3 mr-1" />
                            Unassigned
                          </Badge>
                        )}
                        <span className="text-gray-400">
                          <Clock className="w-3 h-3 inline mr-1" />
                          {formatTime(chat.createdAt)}
                        </span>
                      </div>
                    </button>
                  );
                })}
              </div>
            )}
          </Card>

          {/* Chat Window */}
          <Card className="lg:col-span-2 flex flex-col h-[calc(100vh-320px)]">
            {selectedChat ? (
              <>
                {/* Chat Header */}
                <div className="p-4 border-b bg-white">
                  <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                    <div className="flex items-center gap-3">
                      <div className="w-10 h-10 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--t-color)' }}>
                        <User className="w-5 h-5 text-gray-600" />
                      </div>
                      <div>
                        <h3 className="text-xl" style={{ color: 'var(--s-color)' }}>{selectedChat.guestName}</h3>
                        {selectedChat.guestEmail && (
                          <p className="text-sm text-gray-500">{selectedChat.guestEmail}</p>
                        )}
                      </div>
                    </div>
                    <div className="flex gap-2">
                      {!selectedChat.assignedTo && (
                        <Button
                          variant="outline"
                          size="sm"
                          onClick={() => assignToMe(selectedChat.id)}
                          className="hover:border-green-500 hover:text-green-600"
                        >
                          <UserCheck className="w-4 h-4 mr-2" />
                          Assign to Me
                        </Button>
                      )}
                      <Button
                        variant="outline"
                        size="sm"
                        onClick={() => closeChat(selectedChat.id)}
                        className="hover:border-red-500 hover:text-red-600"
                      >
                        <CheckCircle2 className="w-4 h-4 mr-2" />
                        Close Chat
                      </Button>
                    </div>
                  </div>
                </div>

                {/* Messages */}
                <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                  {selectedChat.messages.length === 0 ? (
                    <div className="flex items-center justify-center h-full text-gray-400">
                      <div className="text-center">
                        <MessageCircle className="w-12 h-12 mx-auto mb-2 text-gray-300" />
                        <p className="text-sm">No messages yet</p>
                        <p className="text-xs mt-1">Start the conversation</p>
                      </div>
                    </div>
                  ) : (
                    <>
                      {selectedChat.messages.map((msg: any) => (
                        <div
                          key={msg.id}
                          className={`flex ${msg.sender === 'agent' ? 'justify-end' : 'justify-start'}`}
                        >
                          <div
                            className={`max-w-[75%] rounded-lg px-4 py-2 shadow-sm ${''}`}
                            style={msg.sender === 'agent' ? {
                              backgroundColor: 'var(--p-color)',
                              color: 'white'
                            } : {
                              backgroundColor: 'white',
                              border: '1px solid #e5e7eb'
                            }}
                          >
                            <div className={`text-xs mb-1 ${msg.sender === 'agent' ? 'opacity-75' : 'text-gray-500'}`}>
                              {msg.senderName}
                            </div>
                            <p className="break-words">{msg.text}</p>
                            <div className={`text-xs mt-1 ${msg.sender === 'agent' ? 'opacity-75' : 'text-gray-400'}`}>
                              {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                            </div>
                          </div>
                        </div>
                      ))}
                      <div ref={messagesEndRef} />
                    </>
                  )}
                </div>

                {/* Input */}
                <div className="p-4 border-t bg-white">
                  <div className="flex gap-2">
                    <Input
                      value={message}
                      onChange={(e) => setMessage(e.target.value)}
                      onKeyPress={(e) => {
                        if (e.key === 'Enter' && !e.shiftKey) {
                          e.preventDefault();
                          sendMessage();
                        }
                      }}
                      placeholder="Type your message..."
                      disabled={sending}
                      className="flex-1"
                    />
                    <Button 
                      onClick={sendMessage} 
                      disabled={!message.trim() || sending}
                      style={{ backgroundColor: 'var(--p-color)' }}
                      className="hover:opacity-90"
                    >
                      {sending ? (
                        <Loader2 className="w-4 h-4 animate-spin" />
                      ) : (
                        <Send className="w-4 h-4" />
                      )}
                    </Button>
                  </div>
                  <p className="text-xs text-gray-500 mt-2">Press Enter to send, Shift+Enter for new line</p>
                </div>
              </>
            ) : (
              <div className="flex-1 flex items-center justify-center text-gray-500 bg-gray-50">
                <div className="text-center">
                  <MessageCircle className="w-16 h-16 mx-auto mb-4 text-gray-300" />
                  <p className="text-lg">Select a chat to start messaging</p>
                  <p className="text-sm text-gray-400 mt-2">Choose from the active chats on the left</p>
                </div>
              </div>
            )}
          </Card>
        </div>
      </div>
    </div>
  );
}