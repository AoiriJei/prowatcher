import { useState, useEffect, useRef } from 'react';
import { MessageCircle, X, Send } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';
import { projectId, publicAnonKey } from '../utils/supabase/info';

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [chatId, setChatId] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);
  const [inputMessage, setInputMessage] = useState('');
  const [guestName, setGuestName] = useState('');
  const [guestEmail, setGuestEmail] = useState('');
  const [hasStarted, setHasStarted] = useState(false);
  const [autoReplyMessage, setAutoReplyMessage] = useState('Thanks for reaching out! An agent will be with you shortly.');
  const [showFAQs, setShowFAQs] = useState(true);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // FAQ data
  const faqs = [
    {
      id: 1,
      question: "What services does ProWatcher offer?",
      answer: "ProWatcher specializes in integrated auxiliary systems solutions including:\n• Building Management Systems (BMS)\n• Fire Detection and Alarm Systems (FDAS)\n• CCTV Surveillance Systems\n• Access Control Systems\n• Public Address Systems\n\nWould you like specific information about any of these services?"
    },
    {
      id: 2,
      question: "How do I request a quote?",
      answer: "You can request a quote by:\n1. Filling out the contact form on our website\n2. Calling us at +63 917 275 2840\n3. Emailing info@prowatcher.com.ph\n4. Continuing this chat with your project details\n\nPlease provide information about your property type, size, and specific security needs for an accurate quote."
    },
    {
      id: 3,
      question: "What is your service area?",
      answer: "ProWatcher is based in Manila, Philippines at 309 Dir. A. Bunye, Manila, Kalakhang Maynila. We serve clients throughout Metro Manila and surrounding areas. For projects outside our standard service area, please contact us to discuss availability."
    },
    {
      id: 4,
      question: "Do you provide maintenance services?",
      answer: "Yes! ProWatcher offers comprehensive maintenance and support services for all installed systems. We provide regular inspections, preventive maintenance, emergency repairs, and system upgrades. Contact us to learn more about our maintenance packages."
    }
  ];

  // Fetch settings on mount
  useEffect(() => {
    const fetchSettings = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/settings`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          if (data.settings?.autoReply) {
            setAutoReplyMessage(data.settings.autoReply);
          }
        }
      } catch (error) {
        // Use default message if fetch fails
        console.error('Error fetching settings:', error);
      }
    };

    fetchSettings();
  }, []);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  // Poll for new messages every 3 seconds
  useEffect(() => {
    if (!chatId || !isOpen) return;

    const pollMessages = async () => {
      try {
        const response = await fetch(
          `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}`,
          {
            headers: {
              'Authorization': `Bearer ${publicAnonKey}`,
            },
          }
        );

        if (response.ok) {
          const data = await response.json();
          setMessages(data.chat.messages);
        }
      } catch (error) {
        console.error('Error polling messages:', error);
      }
    };

    const interval = setInterval(pollMessages, 3000);
    return () => clearInterval(interval);
  }, [chatId, isOpen]);

  const startChat = async () => {
    try {
      const response = await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({ guestName, guestEmail }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        setChatId(data.chatId);
        setHasStarted(true);
        
        // Add auto-reply message
        setTimeout(() => {
          setMessages([{
            id: 'auto',
            text: autoReplyMessage,
            sender: 'agent',
            senderName: 'System',
            timestamp: new Date().toISOString()
          }]);
        }, 500);
      }
    } catch (error) {
      console.error('Error starting chat:', error);
    }
  };

  const handleFAQClick = async (faq: typeof faqs[0]) => {
    if (!chatId) return;
    
    setShowFAQs(false);
    
    // Add user question
    const questionMessage = {
      id: Date.now().toString(),
      text: faq.question,
      sender: 'guest',
      senderName: guestName || 'You',
      timestamp: new Date().toISOString()
    };
    
    setMessages(prev => [...prev, questionMessage]);
    
    // Add bot answer after a short delay
    setTimeout(() => {
      const answerMessage = {
        id: (Date.now() + 1).toString(),
        text: faq.answer,
        sender: 'agent',
        senderName: 'ProWatcher Bot',
        timestamp: new Date().toISOString()
      };
      setMessages(prev => [...prev, answerMessage]);
    }, 800);
    
    // Send to backend
    try {
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}/messages`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            message: faq.question,
            sender: 'guest',
            senderName: guestName || 'Guest',
          }),
        }
      );
      
      // Send bot response
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}/messages`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            message: faq.answer,
            sender: 'agent',
            senderName: 'ProWatcher Bot',
          }),
        }
      );
    } catch (error) {
      console.error('Error sending FAQ messages:', error);
    }
  };

  const sendMessage = async () => {
    if (!inputMessage.trim() || !chatId) return;

    const messageText = inputMessage;
    setInputMessage('');

    // Optimistically add message to UI
    const tempMessage = {
      id: Date.now().toString(),
      text: messageText,
      sender: 'guest',
      senderName: guestName || 'You',
      timestamp: new Date().toISOString()
    };
    setMessages(prev => [...prev, tempMessage]);

    try {
      await fetch(
        `https://${projectId}.supabase.co/functions/v1/make-server-cb79a450/chats/${chatId}/messages`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer ${publicAnonKey}`,
          },
          body: JSON.stringify({
            message: messageText,
            sender: 'guest',
            senderName: guestName || 'Guest',
          }),
        }
      );
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 w-14 h-14 bg-[rgb(170,5,16)] text-white rounded-full shadow-lg hover:bg-blue-700 transition-all flex items-center justify-center z-50"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 w-96 h-[500px] flex flex-col shadow-2xl z-50">
          {/* Header */}
          <div className="bg-[rgb(170,5,16)] text-white p-4 rounded-t-lg flex justify-between items-center">
            <div>
              <h3>Chat with us</h3>
              <p className="text-xs text-blue-100">We typically reply in minutes</p>
            </div>
            <button onClick={() => setIsOpen(false)} className="text-white hover:text-blue-100">
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages or Start Form */}
          {!hasStarted ? (
            <div className="flex-1 p-6 flex flex-col justify-center">
              <h4 className="text-xl mb-4">Start a conversation</h4>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm mb-1">Your Name</label>
                  <Input
                    value={guestName}
                    onChange={(e) => setGuestName(e.target.value)}
                    placeholder="John Smith"
                  />
                </div>
                <div>
                  <label className="block text-sm mb-1">Email (Optional)</label>
                  <Input
                    type="email"
                    value={guestEmail}
                    onChange={(e) => setGuestEmail(e.target.value)}
                    placeholder="john@example.com"
                  />
                </div>
                <Button className="w-full" onClick={startChat}>
                  Start Chat
                </Button>
              </div>
            </div>
          ) : (
            <>
              {/* Messages */}
              <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-gray-50">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`flex ${msg.sender === 'guest' ? 'justify-end' : 'justify-start'}`}
                  >
                    <div
                      className={`max-w-[80%] rounded-lg px-4 py-2 ${
                        msg.sender === 'guest'
                          ? 'bg-blue-600 text-white'
                          : 'bg-white border'
                      }`}
                    >
                      {msg.sender === 'agent' && (
                        <div className="text-xs text-gray-500 mb-1">{msg.senderName}</div>
                      )}
                      <p className="text-sm whitespace-pre-line">{msg.text}</p>
                      <div className={`text-xs mt-1 ${msg.sender === 'guest' ? 'text-blue-100' : 'text-gray-400'}`}>
                        {new Date(msg.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </div>
                    </div>
                  </div>
                ))}
                
                {/* FAQs */}
                {showFAQs && messages.length > 0 && (
                  <div className="space-y-2 mt-4">
                    <p className="text-xs text-gray-500 text-center mb-2">Quick Questions:</p>
                    {faqs.map((faq) => (
                      <button
                        key={faq.id}
                        onClick={() => handleFAQClick(faq)}
                        className="w-full text-left p-3 bg-white border border-gray-200 rounded-lg hover:border-[rgb(170,5,16)] hover:bg-red-50 transition-all text-sm"
                      >
                        {faq.question}
                      </button>
                    ))}
                  </div>
                )}
                
                <div ref={messagesEndRef} />
              </div>

              {/* Input */}
              <div className="p-4 border-t">
                {showFAQs && (
                  <button
                    onClick={() => setShowFAQs(false)}
                    className="text-xs text-gray-500 hover:text-gray-700 mb-2"
                  >
                    Hide quick questions
                  </button>
                )}
                {!showFAQs && messages.length > 1 && (
                  <button
                    onClick={() => setShowFAQs(true)}
                    className="text-xs text-[rgb(170,5,16)] hover:text-red-700 mb-2"
                  >
                    Show quick questions
                  </button>
                )}
                <div className="flex gap-2">
                  <Input
                    value={inputMessage}
                    onChange={(e) => setInputMessage(e.target.value)}
                    onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
                    placeholder="Type a message..."
                  />
                  <Button onClick={sendMessage} size="icon">
                    <Send className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </>
          )}
        </Card>
      )}
    </>
  );
}