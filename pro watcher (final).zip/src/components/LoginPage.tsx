import { useState } from 'react';
import { Lock, UserPlus } from 'lucide-react';
import { Card } from './ui/card';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Label } from './ui/label';
import logoImage from 'figma:asset/664a6dc66cb459802cd67264cdc457a498f7fa7a.png';
import { createManagerAccount } from '../utils/createManager';

interface LoginPageProps {
  onLogin: (email: string, password: string) => Promise<{ success: boolean; error?: string }>;
  onNavigate: (page: string) => void;
}

export default function LoginPage({ onLogin, onNavigate }: LoginPageProps) {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [setupLoading, setSetupLoading] = useState(false);
  const [setupMessage, setSetupMessage] = useState('');

  const handleSetupManager = async () => {
    setSetupLoading(true);
    setSetupMessage('');
    setError('');
    
    try {
      const result = await createManagerAccount();
      
      if (result.success) {
        setSetupMessage('✅ Manager account created! Use: Manager@prowatcher.com.ph / prowatchermanager');
        localStorage.setItem('manager-setup-complete', 'true');
      } else {
        const errorMsg = result.error?.error || JSON.stringify(result.error);
        if (errorMsg.includes('already') || errorMsg.includes('registered') || errorMsg.includes('exists')) {
          setSetupMessage('ℹ️ Manager account already exists. Use: Manager@prowatcher.com.ph / prowatchermanager');
          localStorage.setItem('manager-setup-complete', 'true');
        } else {
          setError('Failed to create manager account: ' + errorMsg);
        }
      }
    } catch (err) {
      setError('Error creating manager account: ' + err);
    } finally {
      setSetupLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const result = await onLogin(email, password);
    
    if (!result.success) {
      setError(result.error || 'Login failed. Please check your credentials.');
    }
    
    setLoading(false);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto p-6">
        <div className="mb-6">
          <div className="flex items-center justify-center gap-3 mb-4">
            <img 
              src={logoImage} 
              alt="ProWatcher Logo" 
              className="h-16 w-auto"
            />
            <div className="w-16 h-16 rounded-full flex items-center justify-center" style={{ backgroundColor: 'var(--p-color)' }}>
              <Lock className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl mb-2 text-center">Staff Portal</h1>
          <p className="text-gray-600 text-center">Sign in to access the dashboard</p>
        </div>

        <div className="space-y-6 max-w-md mx-auto">
          {/* Login Card */}
          <Card className="p-6">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <Label htmlFor="email">Email</Label>
                <Input
                  id="email"
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="staff@prowatcher.com.ph"
                />
              </div>

              <div>
                <Label htmlFor="password">Password</Label>
                <Input
                  id="password"
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                />
              </div>

              {error && (
                <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded text-sm">
                  {error}
                </div>
              )}

              <Button type="submit" className="w-full" size="lg" disabled={loading}>
                {loading ? 'Signing in...' : 'Sign In'}
              </Button>
            </form>
          </Card>

          {/* Info Card */}
          <Card className="p-4 bg-blue-50 border-blue-200">
            <div className="flex items-start gap-3">
              <Lock className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
              <div className="text-sm">
                <p className="font-medium text-blue-900 mb-1">Demo Credentials</p>
                <p className="text-blue-700">
                  To create additional staff accounts, use the User Management section in the admin dashboard. 
                  Use the Setup Manager Account button above to create the manager account.
                </p>
              </div>
            </div>
          </Card>

          {/* Back to Public Site */}
          <div className="text-center">
            <button
              onClick={() => onNavigate('home')}
              className="text-sm text-gray-600 hover:text-blue-600"
            >
              ← Back to Public Site
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}