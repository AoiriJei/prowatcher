import image_bcbac74fabfa7066c4266d8d368c9f363c3b0597 from 'figma:asset/bcbac74fabfa7066c4266d8d368c9f363c3b0597.png';
import image_a3250617f82044f191873b6adf515ee58047c837 from 'figma:asset/a3250617f82044f191873b6adf515ee58047c837.png';
import { Award, Heart, Lightbulb, Shield, Users } from 'lucide-react';
import { Card } from './ui/card';
import logoImage from 'figma:asset/664a6dc66cb459802cd67264cdc457a498f7fa7a.png';

export default function AboutPage() {
  const values = [
    {
      icon: <Heart className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Client First',
      description: 'Your success is our success. We prioritize your needs above all else.',
    },
    {
      icon: <Lightbulb className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Innovation',
      description: 'We stay ahead of the curve with cutting-edge solutions and creative thinking.',
    },
    {
      icon: <Shield className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Integrity',
      description: 'Transparent, honest, and accountable in every interaction.',
    },
    {
      icon: <Award className="w-8 h-8" style={{ color: 'var(--p-color)' }} />,
      title: 'Excellence',
      description: 'We deliver exceptional quality in everything we do.',
    },
  ];

  const team = [
    {
      name: 'Alex Rivera',
      role: 'CEO & Founder',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?w=400&h=400&fit=crop',
      bio: '15+ years of industry experience driving business transformation.',
    },
    {
      name: 'Sarah Chen',
      role: 'Head of Strategy',
      image: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=400&h=400&fit=crop',
      bio: 'Former McKinsey consultant specializing in digital transformation.',
    },
    {
      name: 'Marcus Johnson',
      role: 'Lead Developer',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=400&h=400&fit=crop',
      bio: 'Tech visionary with expertise in scalable enterprise solutions.',
    },
    {
      name: 'Emily Park',
      role: 'Client Success Manager',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=400&h=400&fit=crop',
      bio: 'Dedicated to ensuring every client achieves their goals.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="py-20 px-4" style={{ background: 'linear-gradient(to bottom right, var(--bg-color), white)' }}>
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center items-center gap-3 mb-6">
            <img 
              src={logoImage} 
              alt="ProWatcher Logo" 
              className="h-16 w-auto"
            />
          </div>
          <h1 className="text-5xl mb-6">About Us</h1>
          <p className="text-xl text-gray-600">
            We're on a mission to empower businesses with the tools, strategies, and support they need to thrive in an ever-changing world.
          </p>
        </div>
      </section>

      {/* Company Story */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-4xl mb-6">Our Story</h2>
              <p className="text-gray-600 mb-4">
                was established in 2015, engaged in the supply and installation of Auxiliary System such as CCTV, Fire alarm
                systems, Building Management Systems, Public Address and Background Music, Access Control, and Nurse Call.
              </p>
              <p className="text-gray-600 mb-4">
               Distributor and dealer of different product lines, which made the company known for quality and reliability for the equipment we supplied, installed and commissioned. Our company`s main strength lies in the expertise in Auxiliary
System concepts and design. While our immediate thrust is to seek and establish mutually beneficial relationship with prospective clients, it is fully committed to the continuous
supply as the needed arises.
              </p>
              <p className="text-gray-600">
                Aspart of our continuing efforts, the dynamic team of our company strongly believed in the value and importance of
customer satisfaction. Quality, innovation and customer is our primary concern.
              </p>
            </div>
            <div>
              <img
                src={image_bcbac74fabfa7066c4266d8d368c9f363c3b0597}
                alt="Our office"
                className="rounded-lg shadow-xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Values */}
      <section className="py-20 px-4 bg-gray-50">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-12">
            <h2 className="text-4xl mb-4">ProWatcher System Technologies</h2>
          </div>

          <div className="max-w-4xl mx-auto">
            <Card className="p-8">
              <p className="text-gray-600 mb-6">
                ProWatcher System Technologies provides all of the planning, design, project management, implementation, and start-up services needed, to deliver complex process control projects on-time and on-budget, with minimal down time.
              </p>
              
              <p className="text-gray-600 mb-6">
                With our top-of-the-line product lines, we could integrate field equipment and data with execution system and enterprise resource planning to help efficiency manage every aspect of the operation. ProWatcher can:
              </p>

              <ul className="space-y-4 text-gray-600">
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Find overlooked application opportunities and leverage the full potential of the technology investment through detailed assessment and optimization of the system that drive throughout, controls, and efficiency</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Create a unified automation platform to make the operation more efficient, proactive and productive</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Methodically capture the aggregate knowledge of systems and people, and make it available facility-wide in detailed, decision-supporting tools</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Access existing security measure, designing and monitor an integrated solution of safeguards, including security for physical, electronic and intellectual assets</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Provide a full range of technical support to guarantee a system's viability</span>
                </li>
                <li className="flex items-start gap-3">
                  <span className="text-2xl mt-1" style={{ color: 'var(--p-color)' }}>•</span>
                  <span>Realize an enterprise's highest potential by tapping the existing areas of knowledge and excellence within an organization</span>
                </li>
              </ul>
            </Card>
          </div>
        </div>
      </section>

      {/* Team Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12">
            {/* Mission */}
            <Card className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--p-color)' }}>
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl mb-4">MISSION</h3>
                  <p className="text-gray-600">
                    To build long term relationships with our customers and clients and provide exceptional customer services by pursuing business through innovation and advanced technology.
                  </p>
                </div>
              </div>
            </Card>

            {/* Vision */}
            <Card className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--p-color)' }}>
                  <Lightbulb className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl mb-4">VISION</h3>
                  <p className="text-gray-600">
                    To be globally competitive company and a service provider of choice.
                  </p>
                </div>
              </div>
            </Card>

            {/* Philosophy */}
            <Card className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--p-color)' }}>
                  <Heart className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl mb-4">PHILOSOPHY</h3>
                  <p className="text-gray-600">
                    Service Excellence with integrity, sincerity and professionalism.
                  </p>
                </div>
              </div>
            </Card>

            {/* Values */}
            <Card className="p-8">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--p-color)' }}>
                  <Award className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl mb-4">VALUES</h3>
                  <p className="text-gray-600">
                    Excellence, Teamwork, Honesty, Integrity, Concern for people, Dedication and Committed to Professionalism.
                  </p>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </section>

      {/* Social Proof */}
      <section className="py-20 px-4 text-white" style={{ backgroundColor: 'var(--p-color)' }}>
        <div className="max-w-7xl mx-auto">
          <div className="text-center">
            <div className="text-5xl mb-4">🏆 BEST Performing Contractor of 2024</div>
            <p className="text-xl">Awarded by AFNI PHIL INC</p>
          </div>
        </div>
      </section>
    </div>
  );
}