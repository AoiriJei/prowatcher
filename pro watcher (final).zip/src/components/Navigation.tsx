import { Menu, X } from 'lucide-react';
import { useState } from 'react';
import logoImage from 'figma:asset/664a6dc66cb459802cd67264cdc457a498f7fa7a.png';
import { Button } from './ui/button';

interface NavigationProps {
  currentPage: string;
  onNavigate: (page: string) => void;
  isLoggedIn: boolean;
  onLogout: () => void;
}

export default function Navigation({ currentPage, onNavigate, isLoggedIn, onLogout }: NavigationProps) {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navItems = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About' },
    { id: 'services', label: 'Services' },
    { id: 'projects', label: 'Projects' },
    { id: 'contact', label: 'Contact' },
  ];

  return (
    <nav className="bg-white border-b border-gray-200 sticky top-0 z-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <div className="flex-shrink-0">
            <div className="flex items-center gap-2">
              <img 
                src={logoImage} 
                alt="ProWatcher Logo" 
                className="h-10 w-auto"
              />
              <button
                onClick={() => onNavigate('home')}
                className="brand-logo-text"
                style={{ color: 'var(--s-color)' }}
              >
                <span className="brand-logo-pro">PRO</span>
                <span className="brand-logo-watcher">WATCHER</span>
              </button>
            </div>
          </div>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => onNavigate(item.id)}
                style={{
                  color: currentPage === item.id ? 'var(--p-color)' : '#4B5563',
                  borderBottom: currentPage === item.id ? '2px solid var(--p-color)' : 'none',
                }}
                className="pb-1 transition-colors hover:opacity-80"
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Desktop CTA & Auth */}
          <div className="hidden md:flex items-center space-x-4">
            {isLoggedIn ? (
              <>
                <Button variant="outline" onClick={() => onNavigate('dashboard')}>
                  Dashboard
                </Button>
                <Button variant="ghost" onClick={onLogout}>
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Button variant="outline" onClick={() => onNavigate('contact')}>
                  Submit Inquiry
                </Button>
                <Button variant="ghost" onClick={() => onNavigate('login')}>
                  Staff Portal
                </Button>
              </>
            )}
          </div>

          {/* Mobile menu button */}
          <div className="md:hidden">
            <button
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
              className="text-gray-700 hover:opacity-80"
              style={{ color: 'var(--s-color)' }}
            >
              {mobileMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <div className="md:hidden py-4 space-y-2">
            {navItems.map((item) => (
              <button
                key={item.id}
                onClick={() => {
                  onNavigate(item.id);
                  setMobileMenuOpen(false);
                }}
                style={{
                  backgroundColor: currentPage === item.id ? 'rgba(170, 5, 16, 0.1)' : 'transparent',
                  color: currentPage === item.id ? 'var(--p-color)' : '#4B5563',
                }}
                className="block w-full text-left px-4 py-2 rounded hover:bg-gray-50"
              >
                {item.label}
              </button>
            ))}
            <div className="pt-4 space-y-2">
              {isLoggedIn ? (
                <>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      onNavigate('dashboard');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Dashboard
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => {
                      onLogout();
                      setMobileMenuOpen(false);
                    }}
                  >
                    Logout
                  </Button>
                </>
              ) : (
                <>
                  <Button
                    variant="outline"
                    className="w-full"
                    onClick={() => {
                      onNavigate('contact');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Submit Inquiry
                  </Button>
                  <Button
                    variant="ghost"
                    className="w-full"
                    onClick={() => {
                      onNavigate('login');
                      setMobileMenuOpen(false);
                    }}
                  >
                    Staff Portal
                  </Button>
                </>
              )}
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}