import image_a17e0b5a76e1570b0939a548868ce86d41e601b7 from 'figma:asset/a17e0b5a76e1570b0939a548868ce86d41e601b7.png';
import image_bbd2b94ea2999ac6ecb615fd460cb3b4d5ae0786 from 'figma:asset/bbd2b94ea2999ac6ecb615fd460cb3b4d5ae0786.png';
import image_4895c59234aa1b68ffaade766a3a86b292eb99c8 from 'figma:asset/4895c59234aa1b68ffaade766a3a86b292eb99c8.png';
import { Camera, Bell, Settings, Lock, Phone, Shield, MapPin, Calendar } from 'lucide-react';
import { Card } from './ui/card';

export default function ProjectsPage() {
  const projects = [
    {
      company: 'Clark International Airport',
      location: 'Clark Field, Mabalacat, Pampanga',
      year: '2021',
      image: image_4895c59234aa1b68ffaade766a3a86b292eb99c8,
      services: [
        { icon: <Camera className="w-5 h-5" />, name: 'CCTV & Security Systems' },
        { icon: <Lock className="w-5 h-5" />, name: 'Access Control Systems' },
        { icon: <Settings className="w-5 h-5" />, name: 'Building Management Systems (BMS)' },
      ],
      description: 'Comprehensive security and building automation solutions for the new Clark International Airport terminal, ensuring world-class safety standards and operational efficiency for one of the Philippines\' premier aviation hubs.',
    },
    {
      company: 'Cognizant - Honeywell BMS Integration',
      location: 'Multi-site: Cebu, Alabang, Taguig (Server: Pasig)',
      year: '2021',
      image: image_bbd2b94ea2999ac6ecb615fd460cb3b4d5ae0786,
      services: [
        { icon: <Settings className="w-5 h-5" />, name: 'Distributed System Architecture' },
        { icon: <Settings className="w-5 h-5" />, name: 'Multi-Location BMS Integration' },
        { icon: <Settings className="w-5 h-5" />, name: 'Centralized Smart BMS Server' },
      ],
      description: 'Advanced Honeywell Building Management System integration across three Cognizant facilities (Vector 3 Alabang, Skyrise Cebu, Science Hub Taguig) controlled by one centralized smart BMS server located in Pasig. Distributed system architecture enables seamless monitoring and control of all locations from a single platform.',
    },
    {
      company: 'BDO Towers Paseo',
      location: 'Paseo St, Makati City',
      year: '2022',
      image: image_a17e0b5a76e1570b0939a548868ce86d41e601b7,
      services: [
        { icon: <Bell className="w-5 h-5" />, name: 'Honeywell Fire Detection Alarm System' },
      ],
      description: 'Installation and commissioning of advanced Honeywell Fire Detection and Alarm System for BDO Towers Paseo in Makati City, providing comprehensive fire safety and early warning capabilities for this premium commercial office building.',
    },
  ];

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="py-20 px-4" style={{ backgroundColor: 'var(--s-color)' }}>
        <div className="max-w-7xl mx-auto text-center text-white">
          <h1 className="text-5xl mb-6">Completed Projects</h1>
          <p className="text-xl text-gray-300 max-w-3xl mx-auto">
            Showcasing our expertise in delivering integrated auxiliary system solutions across diverse industries
          </p>
        </div>
      </section>

      {/* Projects Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto space-y-16">
          {projects.map((project, index) => (
            <Card key={index} className="overflow-hidden">
              <div className={`grid md:grid-cols-2 gap-8 ${index % 2 === 1 ? 'md:grid-flow-dense' : ''}`}>
                {/* Image */}
                <div className={index % 2 === 1 ? 'md:col-start-2' : ''}>
                  <img
                    src={project.image}
                    alt={project.company}
                    className="w-full h-full object-cover min-h-[400px]"
                  />
                </div>

                {/* Content */}
                <div className="p-8 flex flex-col justify-center">
                  <div className="mb-4">
                    <h2 className="text-3xl mb-3">{project.company}</h2>
                    <div className="flex flex-wrap gap-4 text-gray-600 text-sm">
                      <div className="flex items-center gap-2">
                        <MapPin className="w-4 h-4" style={{ color: 'var(--p-color)' }} />
                        <span>{project.location}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Calendar className="w-4 h-4" style={{ color: 'var(--p-color)' }} />
                        <span>2022</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6">
                    {project.description}
                  </p>

                  <div>
                    <h3 className="text-lg mb-4">Services Provided:</h3>
                    <div className="grid grid-cols-1 gap-3">
                      {project.services.map((service, idx) => (
                        <div key={idx} className="flex items-center gap-3 text-gray-700">
                          <div className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0" style={{ backgroundColor: 'var(--bg-color)' }}>
                            <div style={{ color: 'var(--p-color)' }}>
                              {service.icon}
                            </div>
                          </div>
                          <span>{service.name}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 px-4 text-white" style={{ backgroundColor: 'var(--p-color)' }}>
        <div className="max-w-4xl mx-auto text-center">
          <h2 className="text-4xl mb-6">Ready to Start Your Project?</h2>
          <p className="text-xl mb-8 text-gray-100">
            Let us help you design and implement the perfect auxiliary systems solution for your facility
          </p>
        </div>
      </section>
    </div>
  );
}