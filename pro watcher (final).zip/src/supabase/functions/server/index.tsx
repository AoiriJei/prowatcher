import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import { createClient } from "npm:@supabase/supabase-js@2";
import * as kv from "./kv_store.tsx";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Initialize Supabase client
const supabase = createClient(
  Deno.env.get('SUPABASE_URL') ?? '',
  Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
);

// Health check endpoint
app.get("/make-server-cb79a450/health", (c) => {
  return c.json({ status: "ok" });
});

// ====== AUTH ROUTES ======

// Sign up new user
app.post("/make-server-cb79a450/auth/signup", async (c) => {
  try {
    const { email, password, name, role = 'agent' } = await c.req.json();

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name, role },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      // Handle specific error cases - check both error.code and error properties
      if (error.code === 'email_exists' || 
          error.message?.includes('already registered') || 
          error.message?.includes('already exists') || 
          error.message?.includes('already been registered')) {
        // User already exists - log as info, not error
        console.log('ℹ️ Signup attempt for existing email:', email);
        return c.json({ 
          error: 'A user with this email address already exists. Please use a different email or try logging in.' 
        }, 409); // 409 Conflict status code
      }
      
      // For other errors, log as error
      console.error('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.error('Signup exception:', error);
    return c.json({ error: 'Signup failed' }, 500);
  }
});

// ====== INQUIRY ROUTES ======

// Submit contact form inquiry
app.post("/make-server-cb79a450/inquiries", async (c) => {
  try {
    const inquiry = await c.req.json();
    const id = crypto.randomUUID();
    
    const inquiryData = {
      id,
      ...inquiry,
      status: 'new',
      createdAt: new Date().toISOString(),
      notes: []
    };

    await kv.set(`inquiry:${id}`, inquiryData);
    
    return c.json({ success: true, id });
  } catch (error) {
    console.error('Error creating inquiry:', error);
    return c.json({ error: 'Failed to submit inquiry' }, 500);
  }
});

// Get all inquiries (protected)
app.get("/make-server-cb79a450/inquiries", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const inquiries = await kv.getByPrefix('inquiry:');
    return c.json({ inquiries: inquiries || [] });
  } catch (error) {
    console.error('Error fetching inquiries:', error);
    return c.json({ error: 'Failed to fetch inquiries' }, 500);
  }
});

// Update inquiry status (protected)
app.put("/make-server-cb79a450/inquiries/:id", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const id = c.req.param('id');
    const updates = await c.req.json();
    
    const existing = await kv.get(`inquiry:${id}`);
    if (!existing) {
      return c.json({ error: 'Inquiry not found' }, 404);
    }

    const updated = { ...existing, ...updates };
    await kv.set(`inquiry:${id}`, updated);
    
    return c.json({ success: true, inquiry: updated });
  } catch (error) {
    console.error('Error updating inquiry:', error);
    return c.json({ error: 'Failed to update inquiry' }, 500);
  }
});

// ====== CHAT ROUTES ======

// Create new chat session
app.post("/make-server-cb79a450/chats", async (c) => {
  try {
    const { guestName, guestEmail } = await c.req.json();
    const chatId = crypto.randomUUID();
    
    const chatData = {
      id: chatId,
      guestName: guestName || 'Guest',
      guestEmail: guestEmail || null,
      status: 'active',
      messages: [],
      assignedTo: null,
      createdAt: new Date().toISOString()
    };

    await kv.set(`chat:${chatId}`, chatData);
    
    return c.json({ chatId, chat: chatData });
  } catch (error) {
    console.error('Error creating chat:', error);
    return c.json({ error: 'Failed to create chat' }, 500);
  }
});

// Get all active chats (protected)
app.get("/make-server-cb79a450/chats", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const chats = await kv.getByPrefix('chat:');
    return c.json({ chats: chats || [] });
  } catch (error) {
    console.error('Error fetching chats:', error);
    return c.json({ error: 'Failed to fetch chats' }, 500);
  }
});

// Get specific chat
app.get("/make-server-cb79a450/chats/:id", async (c) => {
  try {
    const chatId = c.req.param('id');
    const chat = await kv.get(`chat:${chatId}`);
    
    if (!chat) {
      return c.json({ error: 'Chat not found' }, 404);
    }
    
    return c.json({ chat });
  } catch (error) {
    console.error('Error fetching chat:', error);
    return c.json({ error: 'Failed to fetch chat' }, 500);
  }
});

// Add message to chat
app.post("/make-server-cb79a450/chats/:id/messages", async (c) => {
  try {
    const chatId = c.req.param('id');
    const { message, sender, senderName } = await c.req.json();
    
    const chat = await kv.get(`chat:${chatId}`);
    if (!chat) {
      return c.json({ error: 'Chat not found' }, 404);
    }

    const newMessage = {
      id: crypto.randomUUID(),
      text: message,
      sender, // 'guest' or 'agent'
      senderName: senderName || (sender === 'guest' ? chat.guestName : 'Agent'),
      timestamp: new Date().toISOString()
    };

    chat.messages.push(newMessage);
    await kv.set(`chat:${chatId}`, chat);
    
    return c.json({ success: true, message: newMessage });
  } catch (error) {
    console.error('Error adding message:', error);
    return c.json({ error: 'Failed to add message' }, 500);
  }
});

// Assign chat to agent (protected)
app.put("/make-server-cb79a450/chats/:id/assign", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const chatId = c.req.param('id');
    const { agentId, agentName } = await c.req.json();
    
    const chat = await kv.get(`chat:${chatId}`);
    if (!chat) {
      return c.json({ error: 'Chat not found' }, 404);
    }

    chat.assignedTo = { id: agentId, name: agentName };
    await kv.set(`chat:${chatId}`, chat);
    
    return c.json({ success: true, chat });
  } catch (error) {
    console.error('Error assigning chat:', error);
    return c.json({ error: 'Failed to assign chat' }, 500);
  }
});

// Close chat
app.put("/make-server-cb79a450/chats/:id/close", async (c) => {
  try {
    const chatId = c.req.param('id');
    
    const chat = await kv.get(`chat:${chatId}`);
    if (!chat) {
      return c.json({ error: 'Chat not found' }, 404);
    }

    chat.status = 'closed';
    chat.closedAt = new Date().toISOString();
    await kv.set(`chat:${chatId}`, chat);
    
    return c.json({ success: true, chat });
  } catch (error) {
    console.error('Error closing chat:', error);
    return c.json({ error: 'Failed to close chat' }, 500);
  }
});

// ====== USER MANAGEMENT ROUTES (Admin Only) ======

// Get all users (protected - admin only)
app.get("/make-server-cb79a450/users", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || user.user_metadata?.role !== 'admin') {
      return c.json({ error: 'Unauthorized - Admin access required' }, 403);
    }

    const { data: users, error: listError } = await supabase.auth.admin.listUsers();
    
    if (listError) {
      console.error('Error listing users:', listError);
      return c.json({ error: 'Failed to fetch users' }, 500);
    }

    return c.json({ users });
  } catch (error) {
    console.error('Error fetching users:', error);
    return c.json({ error: 'Failed to fetch users' }, 500);
  }
});

// Delete user (protected - admin only)
app.delete("/make-server-cb79a450/users/:id", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || user.user_metadata?.role !== 'admin') {
      return c.json({ error: 'Unauthorized - Admin access required' }, 403);
    }

    const userId = c.req.param('id');
    const { error: deleteError } = await supabase.auth.admin.deleteUser(userId);
    
    if (deleteError) {
      console.error('Error deleting user:', deleteError);
      return c.json({ error: 'Failed to delete user' }, 500);
    }

    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting user:', error);
    return c.json({ error: 'Failed to delete user' }, 500);
  }
});

// ====== SETTINGS ROUTES (Admin Only) ======

// Get settings (public read for chatbot, admin write)
app.get("/make-server-cb79a450/settings", async (c) => {
  try {
    const settings = await kv.get('site:settings') || {
      chatbotEnabled: true,
      operatingHours: '9 AM - 5 PM EST',
      autoReply: 'Thanks for reaching out! An agent will be with you shortly.',
      dataRetentionDays: 90
    };

    return c.json({ settings });
  } catch (error) {
    console.error('Error fetching settings:', error);
    return c.json({ error: 'Failed to fetch settings' }, 500);
  }
});

// Update settings (admin only)
app.put("/make-server-cb79a450/settings", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || user.user_metadata?.role !== 'admin') {
      return c.json({ error: 'Unauthorized - Admin access required' }, 403);
    }

    const settings = await c.req.json();
    await kv.set('site:settings', settings);

    return c.json({ success: true, settings });
  } catch (error) {
    console.error('Error updating settings:', error);
    return c.json({ error: 'Failed to update settings' }, 500);
  }
});

// ====== DATABASE MANAGEMENT ROUTES (Admin Only) ======

// Get entries by prefix
app.get("/make-server-cb79a450/database/prefix/:prefix", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const prefix = c.req.param('prefix');
    
    // Directly query the database to get both keys and values
    const { data, error: dbError } = await supabase
      .from('kv_store_cb79a450')
      .select('key, value')
      .like('key', `${prefix}%`);
    
    if (dbError) {
      console.error('Error fetching database entries by prefix:', dbError);
      return c.json({ error: 'Failed to fetch entries' }, 500);
    }

    return c.json({ entries: data || [] });
  } catch (error) {
    console.error('Error fetching database entries by prefix:', error);
    return c.json({ error: 'Failed to fetch entries' }, 500);
  }
});

// Add new database entry
app.post("/make-server-cb79a450/database", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || user.user_metadata?.role !== 'admin') {
      return c.json({ error: 'Unauthorized - Admin access required' }, 403);
    }

    const { key, value } = await c.req.json();
    
    if (!key) {
      return c.json({ error: 'Key is required' }, 400);
    }

    await kv.set(key, value);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error adding database entry:', error);
    return c.json({ error: 'Failed to add entry' }, 500);
  }
});

// Delete database entry
app.delete("/make-server-cb79a450/database/:key", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    const { data: { user }, error } = await supabase.auth.getUser(accessToken);
    
    if (!user?.id || user.user_metadata?.role !== 'admin') {
      return c.json({ error: 'Unauthorized - Admin access required' }, 403);
    }

    const key = decodeURIComponent(c.req.param('key'));
    await kv.del(key);
    
    return c.json({ success: true });
  } catch (error) {
    console.error('Error deleting database entry:', error);
    return c.json({ error: 'Failed to delete entry' }, 500);
  }
});

Deno.serve(app.fetch);